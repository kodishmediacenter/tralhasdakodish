# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.vikingspro'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

def addDir(title, url,icon):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':icon,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

    
def kiss_music():
    addDir(title="Não Deixe Rock Sair de Você"            , url="plugin://plugin.video.youtube/playlist/PLSUn1UQk9K4gH0dFgnQqRXxokYeGwIEI8/",icon = "https://www.kissfm.com.br/wp-content/uploads/2019/11/logo_ao_vivo.png")
    addDir(title="Kiss FM Rock Nacional"                  , url="plugin://plugin.video.youtube/playlist/PLSUn1UQk9K4h3ZDUTBNd-Kwu6BDvVALS1/",icon = "https://www.kissfm.com.br/wp-content/uploads/2019/11/logo_ao_vivo.png")
    addDir(title="Kiss FM Anos 90"                        , url="plugin://plugin.video.youtube/playlist/PLSUn1UQk9K4h6MKmNRvdZinZMYVXAJDDa/",icon = "https://www.kissfm.com.br/wp-content/uploads/2019/11/logo_ao_vivo.png")
    addDir(title="Kiss FM Anos 80"                        , url="plugin://plugin.video.youtube/playlist/PLSUn1UQk9K4jQMolwvfiJVqlnTmPEvMDv/",icon = "https://www.kissfm.com.br/wp-content/uploads/2019/11/logo_ao_vivo.png")
    addDir(title="Kiss FM Anos 70"                        , url="plugin://plugin.video.youtube/playlist/PLSUn1UQk9K4i4D-W2wSUSBoPbh8M15_fD/",icon = "https://www.kissfm.com.br/wp-content/uploads/2019/11/logo_ao_vivo.png")
    addDir(title="Kiss 500Mais 2020"                      , url="plugin://plugin.video.youtube/playlist/PLSUn1UQk9K4iF-8-qxZ0898f6okH7VLjN/",icon = "https://www.kissfm.com.br/wp-content/uploads/2019/11/logo_ao_vivo.png")
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
