# -*- coding: utf-8 -*-

import sys

reload(sys)
sys.setdefaultencoding('utf8')

import urllib
import urllib2
import cookielib
import datetime
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
import re
import os
import base64
import codecs
import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback
import time
from BeautifulSoup import BeautifulStoneSoup, BeautifulSOAP
from bs4 import BeautifulSoup
try:
    import json
except:
    import simplejson as json

Versao = '1.0.0'

viewmode=None
#import SimpleDownloader as downloader
tsdownloader=False
resolve_url=['180upload.com', 'allmyvideos.net', 'bestreams.net', 'clicknupload.com', 'cloudzilla.to', 'movshare.net', 'novamov.com', 'nowvideo.sx', 'videoweed.es', 'daclips.in', 'datemule.com', 'fastvideo.in', 'faststream.in', 'filehoot.com', 'filenuke.com', 'sharesix.com', 'docs.google.com', 'plus.google.com', 'picasaweb.google.com', 'gorillavid.com', 'gorillavid.in', 'grifthost.com', 'hugefiles.net', 'ipithos.to', 'ishared.eu', 'kingfiles.net', 'mail.ru', 'my.mail.ru', 'videoapi.my.mail.ru', 'mightyupload.com', 'mooshare.biz', 'movdivx.com', 'movpod.net', 'movpod.in', 'movreel.com', 'mrfile.me', 'nosvideo.com', 'openload.io', 'played.to', 'bitshare.com', 'filefactory.com', 'k2s.cc', 'oboom.com', 'rapidgator.net', 'uploaded.net', 'primeshare.tv', 'bitshare.com', 'filefactory.com', 'k2s.cc', 'oboom.com', 'rapidgator.net', 'uploaded.net', 'sharerepo.com', 'stagevu.com', 'streamcloud.eu', 'streamin.to', 'thefile.me', 'thevideo.me', 'tusfiles.net', 'uploadc.com', 'zalaa.com', 'uploadrocket.net', 'uptobox.com', 'v-vids.com', 'veehd.com', 'vidbull.com', 'videomega.tv', 'vidplay.net', 'vidspot.net', 'vidto.me', 'vidzi.tv', 'vimeo.com', 'vk.com', 'vodlocker.com', 'xfileload.com', 'xvidstage.com', 'zettahost.tv']
g_ignoreSetResolved=['plugin.video.f4mTester','plugin.video.shahidmbcnet','plugin.video.SportsDevil','plugin.stream.vaughnlive.tv','plugin.video.ZemTV-shani']

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_version = addon.getAddonInfo('version')
icon = addon.getAddonInfo('icon')
FANART = addon.getAddonInfo('fanart')
canais_adultos = xbmcaddon.Addon().getSetting("canais_extra")
profile = xbmc.translatePath(addon.getAddonInfo('profile').decode('utf-8'))
home = xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8'))
favorites = os.path.join(profile, 'favorites')
history = os.path.join(profile, 'history')
REV = os.path.join(profile, 'list_revision')
source_file = os.path.join(profile, 'source_file')
functions_dir = profile
add_playlist = addon.getSetting('add_playlist')
ask_playlist_items =addon.getSetting('ask_playlist_items')
use_thumb = addon.getSetting('use_thumb')
player_f4m = addon.getSetting('player_f4m')
donatemsg = '[B]Valeu pela doação [COLOR orangered]THANKS!![/COLOR][/B]'
base_rc = 'https://redecanais.cloud'

if sys.argv[1] == 'donatemercadopago':
    import xbmc
    import webbrowser
    donatetext = '[B][COLOR white]DOAR[/COLOR] [COLOR orangered]%s[/COLOR][/B]'
    dialog = xbmcgui.Dialog()
    donate = dialog.select(donatemsg, [donatetext%('R$ 5'), donatetext%('R$ 10'), donatetext%('R$ 15')])
    if donate == 0:
        if xbmc.getCondVisibility('system.platform.windows'):
            webbrowser.open('https://mpago.la/1U33vqD')
        elif xbmc.getCondVisibility('system.platform.android'):
            xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' %('https://mpago.la/1U33vqD'))
    elif donate == 1:
        if xbmc.getCondVisibility('system.platform.windows'):
            webbrowser.open('https://mpago.la/2rJRbNE')
        elif xbmc.getCondVisibility('system.platform.android'):
            xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' %('https://mpago.la/2rJRbNE'))
    elif donate == 2:
        if xbmc.getCondVisibility('system.platform.windows'):
            webbrowser.open('https://mpago.la/1X5XTYj')
        elif xbmc.getCondVisibility('system.platform.android'):
            xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' %('https://mpago.la/1X5XTYj'))
    exit()

if sys.argv[1] == 'donatepaypal':
    import xbmc
    import webbrowser
    donatetext = '[B][COLOR white]DOAR[/COLOR] [COLOR orangered]%s[/COLOR][/B]'
    dialog = xbmcgui.Dialog()
    donate = dialog.select(donatemsg, [donatetext%('R$ REAIS'), donatetext%('USD DOLAR')])
    if donate == 0:
        if xbmc.getCondVisibility('system.platform.windows'):
            webbrowser.open('https://www.paypal.com/')
        elif xbmc.getCondVisibility('system.platform.android'):
            xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' %('https://www.paypal.com'))
    elif donate == 1:
        if xbmc.getCondVisibility('system.platform.windows'):
            webbrowser.open('https://www.paypal.com/')
        elif xbmc.getCondVisibility('system.platform.android'):
            xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' %('https://www.paypal.com/'))
    exit()

if sys.argv[1] == 'donatepicpay':
    import xbmc
    import webbrowser
    if xbmc.getCondVisibility('system.platform.windows'):
        webbrowser.open('https://app.picpay.com/user/twtutoriais')
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' %('https://app.picpay.com/user/twtutoriais'))
    exit()

if sys.argv[1] == 'siteoficial':
    import xbmc
    import webbrowser
    if xbmc.getCondVisibility('system.platform.windows'):
        webbrowser.open('https://bit.ly/DOWNLOADSTWTUTORIAIS')
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' %('https://bit.ly/DOWNLOADSTWTUTORIAIS'))
    exit()

if sys.argv[1] == 'removerEPG':
    Path = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
    arquivo = os.path.join(Path, "epgbr.xml")
    exists = os.path.isfile(arquivo)
    if exists:
        try:
            os.remove(arquivo)
            xbmc.executebuiltin("XBMC.Notification("+addon_name+", [B]EPG removido com sucesso![/B]"+",600,"+icon+")")
        except:
            pass
    else:
        xbmc.executebuiltin("XBMC.Notification("+addon_name+", [B]EPG não encontrado.[/B]"+",600,"+icon+")")
    xbmcaddon.Addon().setSetting("epg_last", "")
    xbmc.sleep(2000)
    exit()

if sys.argv[1] == 'SetPass':
    addonID = xbmcaddon.Addon().getAddonInfo('id')
    addon_data_path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data', addonID))
    if os.path.exists(addon_data_path)==False:
        os.mkdir(addon_data_path)
    xbmc.sleep(4)
    #Path = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
    #arquivo = os.path.join(Path, "password.txt")
    arquivo = os.path.join(addon_data_path, "pass.txt")
    exists = os.path.isfile(arquivo)
    keyboard = xbmcaddon.Addon().getSetting("keyboard")
    if exists == False:
        password = '0000'
        p_encoded = base64.b64encode(password.encode()).decode('utf-8')
        p_file1 = open(arquivo,'w')
        p_file1.write(p_encoded)
        p_file1.close()
        xbmc.sleep(4)
        p_file = open(arquivo,'r+')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        ps = dialog.numeric(0, 'Insira a senha atual:')
        if ps == p_file_b64_decode:
            ps2 = dialog.numeric(0, 'Insira a nova senha:')
            if ps2 != '':
                ps2_b64 = base64.b64encode(ps2.encode()).decode('utf-8')
                p_file = open(arquivo,'w')
                p_file.write(ps2_b64)
                p_file.close()
                xbmc.executebuiltin("XBMC.Notification("+addon_name+", [B]Senha alterada com sucesso![/B]"+",600,"+icon+")")
            else:
                xbmc.executebuiltin("XBMC.Notification("+addon_name+", [B]Não foi possivel alterar a senha![/B]"+",600,"+icon+")")
        else:
            xbmc.executebuiltin("XBMC.Notification("+addon_name+", [B]Senha invalida![/B]"+",600,"+icon+")")
    else:
        p_file = open(arquivo,'r+')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        ps = dialog.numeric(0, 'Insira a senha atual:')
        if ps == p_file_b64_decode:
            ps2 = dialog.numeric(0, 'Insira a nova senha:')
            if ps2 != '':
                ps2_b64 = base64.b64encode(ps2.encode()).decode('utf-8')
                p_file = open(arquivo,'w')
                p_file.write(ps2_b64)
                p_file.close()
                xbmc.executebuiltin("XBMC.Notification("+addon_name+", [B]Senha alterada com sucesso![/B]"+",600,"+icon+")")
            else:
                xbmc.executebuiltin("XBMC.Notification("+addon_name+", [B]Não foi possivel alterar a senha![/B]"+",600,"+icon+")")
        else:
            xbmc.executebuiltin("XBMC.Notification("+addon_name+", [B]Senha invalida![/B]"+",600,"+icon+")")
    exit()

#downloader = downloader.SimpleDownloader()
debug = addon.getSetting('debug')
compatible = '1646162747E656F256E696364756E6F28796C664F207577756E6F2233756F6A75736F23756F6A75736F256479637E2371686E696577696D627F666371646F64617F2F2A307474786'
useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36'
tam = len(compatible)
basedem = compatible[::-1]
CHBase = base64.b16decode(basedem)

def CHIndex():
    NewsInfos()
    getData(CHBase,'')
    addDir('[B][COLOR white]DOAÇÕES E AJUSTES[/COLOR][/B]','#',7,'','','[B][COLOR white][COLOR orangered]DOAÇÕES[/COLOR] - Picpay - Paypal[/COLOR][CR][COLOR white]CONTROLE DOS PAIS (+18)[/COLOR][CR][COLOR white]GUIA DE PROGRAMAÇÃO (EPG)[/COLOR][/B]','','','')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_data_listas(url):
    getData(url,'')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def addon_log(string):
    if debug == 'true':
        xbmc.log("[addon.TWTNETCINE-%s]: %s" %(addon_version, string))

def notify(message, timeShown=5000):
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (addon_name, message, timeShown, icon))

def makeRequest(url):
        try:
            try:
                import urllib.request as urllib2
            except ImportError:
                import urllib2
            request_headers = {
            "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8,ru;q=0.7,de-DE;q=0.6,de;q=0.5,de-AT;q=0.4,de-CH;q=0.3,ja;q=0.2,zh-CN;q=0.1,zh;q=0.1,zh-TW;q=0.1,es;q=0.1,ar;q=0.1,en-GB;q=0.1,hi;q=0.1,cs;q=0.1,el;q=0.1,he;q=0.1,en-US;q=0.1",
            "User-Agent": useragent,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
            }
            request = urllib2.Request(url, headers=request_headers)
            response = urllib2.urlopen(request).read().decode('utf-8')
            return response
        except urllib2.URLError, e:
            if hasattr(e, 'code'):
                xbmc.executebuiltin("XBMC.Notification(Error, error code - "+str(e.code)+",10000,"+icon+")")
            elif hasattr(e, 'reason'):
                xbmc.executebuiltin("XBMC.Notification(Error, reason - "+str(e.reason)+",10000,"+icon+")")
            response = ''
            return response

def getRequest(url,ref,useragent=False):
    try:
        if ref > '':
            ref = ref
        else:
            ref = url
        if useragent:
            client_user = useragent
        else:
            client_user = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36"
        request_headers = {
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8,ru;q=0.7,de-DE;q=0.6,de;q=0.5,de-AT;q=0.4,de-CH;q=0.3,ja;q=0.2,zh-CN;q=0.1,zh;q=0.1,zh-TW;q=0.1,es;q=0.1,ar;q=0.1,en-GB;q=0.1,hi;q=0.1,cs;q=0.1,el;q=0.1,he;q=0.1,en-US;q=0.1",
        "User-Agent": client_user,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Referer": ref
        }
        request = urllib2.Request(url, headers=request_headers)
        response = urllib2.urlopen(request).read().decode('utf-8')
        return response
    except:
        return ''

def getRequest2(url,ref,useragent=False):
    try:
        if ref > '':
            ref = ref
        else:
            ref = url
        if useragent:
            client_user = useragent
        else:
            client_user = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36"
        cj = cookielib.CookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        opener.addheaders=[('Accept-Language', 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'),('User-Agent', client_user),('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'), ('Referer', ref)]
        data = opener.open(url).read()
        response = data.decode('utf-8')
        return response
    except:
        return ''

def getRequestSSL(url,ref,useragent=False):
    try:
        try:
            import urllib.request as urllib2
        except ImportError:
            import urllib2
        if ref > '':
            ref = ref
        else:
            ref = url
        if useragent:
            client_user = useragent
        else:
            client_user = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36"
        request_headers = {
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8,ru;q=0.7,de-DE;q=0.6,de;q=0.5,de-AT;q=0.4,de-CH;q=0.3,ja;q=0.2,zh-CN;q=0.1,zh;q=0.1,zh-TW;q=0.1,es;q=0.1,ar;q=0.1,en-GB;q=0.1,hi;q=0.1,cs;q=0.1,el;q=0.1,he;q=0.1,en-US;q=0.1",
        "User-Agent": client_user,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Referer": ref
        }
        import ssl
        request = urllib2.Request(url, headers=request_headers)
        response = urllib2.urlopen(request, context=ssl._create_unverified_context()).read().decode('utf-8')
        #response = urllib2.urlopen(request).read()
        return response
    except:
        pass

def getRedirect(url,ref,useragent=False):
    try:
        try:
            import urllib.request as urllib2
        except ImportError:
            import urllib2
        if ref > '':
            ref = ref
        else:
            ref = url
        if useragent:
            client_user = useragent
        else:
            client_user = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36"
        request_headers = {
        "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8,ru;q=0.7,de-DE;q=0.6,de;q=0.5,de-AT;q=0.4,de-CH;q=0.3,ja;q=0.2,zh-CN;q=0.1,zh;q=0.1,zh-TW;q=0.1,es;q=0.1,ar;q=0.1,en-GB;q=0.1,hi;q=0.1,cs;q=0.1,el;q=0.1,he;q=0.1,en-US;q=0.1",
        "User-Agent": client_user,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Referer": ref
        }
        request = urllib2.Request(url, headers=request_headers)
        response = urllib2.urlopen(request).geturl()
        return response
    except:
        pass

#EPG ANTIGO: 
epg_url = base64.b64decode('').decode('utf-8')
epgEnabled = xbmcaddon.Addon().getSetting("epg")
epgLast = xbmcaddon.Addon().getSetting("epg_last")
epgDays = xbmcaddon.Addon().getSetting("epg_days")
base_search_rc = ''
base_search_rc = base64.b64decode(base_search_rc).decode('utf-8')

def NewsInfos():
    try:
        info_decode = '\x61\x48\x52\x30\x63\x44\x6f\x76\x4c\x33\x46\x6b\x62\x32\x52\x68\x63\x32\x5a\x76\x63\x6d\x31\x70\x5a\x33\x56\x70\x62\x6d\x68\x68\x63\x79\x35\x7a\x61\x58\x52\x6c\x4c\x32\x4e\x31\x65\x6d\x39\x6c\x63\x79\x39\x6a\x64\x58\x70\x76\x5a\x58\x4d\x79\x4c\x32\x35\x6c\x64\x33\x56\x77\x4c\x30\x5a\x73\x61\x58\x67\x76\x62\x6d\x56\x30\x59\x32\x6c\x75\x5a\x53\x39\x75\x62\x33\x52\x70'
        info_decode = base64.b64decode(info_decode).decode('utf-8')
        info = urllib2.urlopen(info_decode).read()
        if info.find('<isonline>True</isonline>') >= 0 or info.find('<isonline>true</isonline>') >= 0:
            infoget = re.compile('(.+)').findall(info)[0]
            infonote = infoget.replace(',','.')
            notify('[B]'+infonote+'[/B]')
    except:
        pass

def getSoup(url,data=None):
        #print 'getsoup',url,data
        if url.startswith('http://') or url.startswith('https://'):
            data = makeRequest(url)
            try:
                if 'W63RAOBXWS3TUHURHQYT' in data:
                    data = data.split('W63RAOBXWS3TUHURHQYT')
                    data = base64.b32decode(data[1][::-1])
            except: pass
        else:
            data = makeRequest(url)
        return BeautifulSOAP(data, convertEntities=BeautifulStoneSoup.XML_ENTITIES)

def getData(url,fanart, data=None):
    soup = getSoup(url,data)
    #print type(soup)
    if isinstance(soup,BeautifulSOAP):
    #print 'xxxxxxxxxxsoup',soup
        if len(soup('channels')) > 0:
            channels = soup('channel')
            for channel in channels:
                #print channel
                linkedUrl=''
                lcount=0
                try:
                    linkedUrl =  channel('externallink')[0].string
                    lcount=len(channel('externallink'))
                except: pass
                #print 'linkedUrl',linkedUrl,lcount
                if lcount>1: linkedUrl=''
                name = channel('name')[0].string
                thumbnail = channel('thumbnail')[0].string
                if thumbnail == None:
                    thumbnail = ''
                try:
                    if not channel('fanart'):
                        if addon.getSetting('use_thumb') == "true":
                            fanArt = thumbnail
                        else:
                            fanArt = fanart
                    else:
                        fanArt = channel('fanart')[0].string
                    if fanArt == None:
                        #raise
                        fanArt = ''
                except:
                    fanArt = fanart

                try:
                    desc = channel('info')[0].string
                    if desc == None:
                        #raise
                        desc = ''
                except:
                    desc = ''

                try:
                    genre = channel('genre')[0].string
                    if genre == None:
                        #raise
                        genre = ''
                except:
                    genre = ''

                try:
                    date = channel('date')[0].string
                    if date == None:
                        #raise
                        date = ''
                except:
                    date = ''
                try:
                    if linkedUrl=='':
                        addDir(name.encode('utf-8', 'ignore'),url.encode('utf-8'),2,thumbnail,fanArt,desc,genre,date,True)
                    else:
                        if canais_adultos == 'false' and name.find("CANAIS") >= 0 and name.find("+18") >= 0:
                            pass
                        elif 'rede=' in linkedUrl:
                            linkedUrl = linkedUrl.replace('rede=','')
                            linkedUrl = 'https://redecanais.cloud/browse-' + linkedUrl + '-videos-1-date.html'
                            desc = '[B]OS MELHORES CONTEÚDOS[CR]ACESSE: [COLOR orangered]REDECANAIS.CLOUD[/COLOR][/B]'
                            try:
                                thumbnail = base64.b64decode(thumbnail).decode('utf-8')
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl.encode('utf-8'),55,thumbnail,fanArt,desc,genre,date,None)
                        elif 'netcine=' in linkedUrl:
                            linkedUrl = linkedUrl.replace('netcine=','')
                            linkedUrl = 'https://netcine.biz/tvshows/' + linkedUrl
                            desc = '[B]OS MELHORES CONTEÚDOS[CR]ACESSE: [COLOR orangered]NETCINE.BIZ[/COLOR][/B]'
                            try:
                                thumbnail = base64.b64decode(thumbnail).decode('utf-8')
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl.encode('utf-8'),59,thumbnail,fanArt,desc,genre,date,None)
                        elif '#netcine_menu' in linkedUrl:
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl.encode('utf-8'),59,thumbnail,fanArt,desc,genre,date,None)
                        elif 'pornhub=' in linkedUrl:
                            linkedUrl = linkedUrl.replace('pornhub=','')
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl.encode('utf-8'),58,thumbnail,fanArt,desc,genre,date,None)
                        elif '#home=search_redecanais#' in linkedUrl:
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl.encode('utf-8'),54,thumbnail,fanArt,desc,genre,date,None)
                            global pesquisa_desativar
                            global search
                            pesquisa_desativar = 'false'
                            search = ''
                        else:
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl.encode('utf-8'),1,thumbnail,fanArt,desc,genre,date,None)
                except:
                    addon_log('Ocorreu um problema ao carregar os dados!')
                    #notify('[COLOR red]Ocorreu um problema ao carregar os dados![/COLOR]')
        else:
            getItems(soup('item'),fanart)
    else:
        #parse_m3u(soup)
        notify('[COLOR red]Ocorreu um problema ao carregar os dados![/COLOR]')

def parse_m3u(data):
    content = data.rstrip()
    match = re.compile(r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)').findall(content)
    total = len(match)
    #print 'tsdownloader',tsdownloader
    #print 'total m3u links',total
    for other,channel_name,stream_url in match:
        if 'tvg-logo' in other:
            thumbnail = re_me(other,'tvg-logo=[\'"](.*?)[\'"]')
            if thumbnail:
                if thumbnail.startswith('http'):
                    thumbnail = thumbnail
                elif not addon.getSetting('logo-folderPath') == "":
                    logo_url = addon.getSetting('logo-folderPath')
                    thumbnail = logo_url + thumbnail
                else:
                    thumbnail = thumbnail
            #else:
        else:
            thumbnail = ''
        if 'type' in other:
            mode_type = re_me(other,'type=[\'"](.*?)[\'"]')
            if mode_type == 'yt-dl':
                stream_url = stream_url +"&mode=18"
            elif mode_type == 'regex':
                url = stream_url.split('&regexs=')
                #print url[0] getSoup(url,data=None)
                regexs = parse_regex(getSoup('',data=url[1]))
                addLink(url[0], channel_name,thumbnail,'','','','','',None,regexs,total)
                continue
            elif mode_type == 'ftv':
                stream_url = 'plugin://plugin.video.F.T.V/?name='+urllib.quote(channel_name) +'&url=' +stream_url +'&mode=125&ch_fanart=na'
        elif tsdownloader and '.ts' in stream_url:
            stream_url = 'plugin://plugin.video.f4mTester/?url='+urllib.quote_plus(stream_url)+'&streamtype=TSDOWNLOADER&name='+urllib.quote(channel_name)
        addLink(stream_url, channel_name,thumbnail,'','','','','',None,'',total)


def getChannelItems(name,url,fanart):
        soup = getSoup(url)
        channel_list = soup.find('channel', attrs={'name' : name.decode('utf-8')})
        items = channel_list('item')
        try:
            fanArt = channel_list('fanart')[0].string
            if fanArt == None:
                #raise
                fanArt = ''
        except:
            fanArt = fanart
        for channel in channel_list('subchannel'):
            name = channel('name')[0].string
            try:
                thumbnail = channel('thumbnail')[0].string
                if thumbnail == None:
                    #raise
                    thumbnail = ''
            except:
                thumbnail = ''
            try:
                if not channel('fanart'):
                    if addon.getSetting('use_thumb') == "true":
                        fanArt = thumbnail
                else:
                    fanArt = channel('fanart')[0].string
                if fanArt == None:
                    #raise
                    fanArt = ''
            except:
                pass
            try:
                desc = channel('info')[0].string
                if desc == None:
                    #raise
                    desc = ''
            except:
                desc = ''

            try:
                genre = channel('genre')[0].string
                if genre == None:
                    #raise
                    genre = ''
            except:
                genre = ''

            try:
                date = channel('date')[0].string
                if date == None:
                    #raise
                    date = ''
            except:
                date = ''

            try:
                addDir(name.encode('utf-8', 'ignore'),url.encode('utf-8'),3,thumbnail,fanArt,desc,genre,date)
            except:
                notify('[COLOR red]Ocorreu um problema ao carregar os dados![/COLOR]')
        getItems(items,fanArt)

def getItems(items,fanart,dontLink=False):
    if epgEnabled == "true":
        epg_search = items
        try:
            for item in epg_search:
                if item('epg_active'):
                    epg_search = 'true'
                    break
                else:
                    break
        except:
            epg_search = 'false'
        if epg_search == 'true':
            epginfo = epgParseData()
    total = len(items)
    #addon_log('Total Items: %s' %total)
    for item in items:
        isXMLSource=False
        isJsonrpc = False
        try:
            name = item('title')[0].string
            if ';' in name:
                name = name.replace(';','')
            if name is None:
                name = 'unknown?'
        except:
            addon_log('Name Error')
            name = ''
        try:
            url = []
            if len(item('link')) >0:
                #print 'item link', item('link')
                for i in item('link'):
                    if not i.string == None:
                        url.append(i.string)
            if len(url) < 1:
                raise
                #url = ''
        except:
            addon_log('Error <link> element, Passing:'+name.encode('utf-8', 'ignore'))
            continue
        if epgEnabled == "true":
            if url == 'here' and 'CANAIS ABERTOS' in name or 'CANAIS ABERTOS' in name or 'DOCUMENTÁRIOS' in name or 'ESPORTES' in name or 'FILMES & SÉRIES' in name or 'INFATIL' in name or 'MÚSICAS & VARIEDADES' in name or 'NOTÍCIAS' in name:
                name = name + ' [B]ATUALIZAR EPG[/B]'
        try:
            isXMLSource = item('externallink')[0].string
        except: pass
        if isXMLSource:
            ext_url=[isXMLSource]
            isXMLSource=True
        else:
            isXMLSource=False
        try:
            isJsonrpc = item('jsonrpc')[0].string
        except: pass
        if isJsonrpc:
            ext_url=[isJsonrpc]
            #print 'JSON-RPC ext_url',ext_url
            isJsonrpc=True
        else:
            isJsonrpc=False
        try:
            thumbnail = item('thumbnail')[0].string
            if thumbnail == None:
                #raise
                thumbnail = ''
        except:
            thumbnail = ''
        try:
            if not item('fanart'):
                if addon.getSetting('use_thumb') == "true":
                    fanArt = thumbnail
                else:
                    fanArt = fanart
            else:
                fanArt = item('fanart')[0].string
            if fanArt == None:
                #raise
                fanArt = ''
        except:
            fanArt = fanart
        try:
            desc = item('info')[0].string
            if desc == None:
                #raise
                desc = ''
        except:
            desc = ''
        try:
            if epgEnabled == "true":
                if not '.mp4' in url:
                    if item('epgid'):
                        EPG_Get = getID_EPG(name)
                        if EPG_Get == '':
                            pass
                        else:
                            epg, desc_epg = getEPG(epginfo,EPG_Get)
                            name = name + epg
                            desc = desc_epg
        except:
            pass
        try:
            genre = item('genre')[0].string
            if genre == None:
                #raise
                genre = ''
        except:
            genre = ''
        try:
            date = item('date')[0].string
            if date == None:
                #raise
                date = ''
        except:
            date = ''
        regexs = None
        if item('regex'):
            try:
                reg_item = item('regex')
                regexs = parse_regex(reg_item)
            except:
                pass
        try:
            if len(url) > 1:
                alt = 0
                playlist = []
                ignorelistsetting=True if '$$LSPlayOnlyOne$$' in url[0] else False
                for i in url:
                        if  add_playlist == "false":
                            alt += 1
                            addLink(i,'%s) %s' %(alt, name.encode('utf-8', 'ignore')),thumbnail,fanArt,desc,genre,date,True,playlist,regexs,total)
                        elif  add_playlist == "true" and  ask_playlist_items == 'true':
                            if regexs:
                                playlist.append(i+'&regexs='+regexs)
                            elif  any(x in i for x in resolve_url) and  i.startswith('http'):
                                playlist.append(i+'&mode=19')
                            else:
                                playlist.append(i)
                        else:
                            playlist.append(i)
                if len(playlist) > 1:
                    addLink('', name.encode('utf-8'),thumbnail,fanArt,desc,genre,date,True,playlist,regexs,total)
            else:
                if dontLink:
                    return name,url[0],regexs
                if isXMLSource:
                        if not regexs == None: #<externallink> and <regex>
                            addDir(name.encode('utf-8'),ext_url[0].encode('utf-8'),1,thumbnail,fanart,desc,genre,date,None,'!!update',regexs,url[0].encode('utf-8'))
                            #addLink(url[0],name.encode('utf-8', 'ignore')+  '[COLOR yellow]build XML[/COLOR]',thumbnail,fanArt,desc,genre,date,True,None,regexs,total)
                        else:
                            addDir(name.encode('utf-8'),ext_url[0].encode('utf-8'),1,thumbnail,fanart,desc,genre,date,None,'source',None,None)
                            #addDir(name.encode('utf-8'),url[0].encode('utf-8'),1,thumbnail,fanart,desc,genre,date,None,'source')
                elif isJsonrpc:
                    addDir(name.encode('utf-8'),ext_url[0],53,thumbnail,fanart,desc,genre,date,None,'source')
                    #xbmc.executebuiltin("Container.SetViewMode(500)")
                else:
                    addLink(url[0],name.encode('utf-8', 'ignore'),thumbnail,fanArt,desc,genre,date,True,None,regexs,total)
                #print 'success'
        except:
            notify('[COLOR red]Ocorreu um problema ao carregar os items![/COLOR]')

def getSubChannelItems(name,url,fanart):
    soup = getSoup(url)
    channel_list = soup.find('subchannel', attrs={'name' : name.decode('utf-8')})
    items = channel_list('subitem')
    getItems(items,fanart)

def remove_repetidos(keys):
    l = []
    for i in keys:
        if i not in l:
            l.append(i)
    l.sort()
    return l

def editar_txt(txt):
    keys = {}
    x = {'&Aacute;':'Á','&aacute;':'á','&Acirc;':'Â','&acirc;':'â','&Agrave;':'À','&agrave;':'à','&Aring;':'Å','&aring;':'å','&Atilde;':'Ã','&atilde;':'ã','&Auml;':'Ä','&auml;':'ä','&AElig;':'Æ','&aelig;':'æ','&Eacute;':'É','&eacute;':'é','&Ecirc;':'Ê','&ecirc;':'ê','&Egrave;':'È','&egrave;':'è','&Euml;':'Ë','&euml;':'ë','&ETH;':'Ð','&eth;':'ð','&Iacute;':'Í','&iacute;':'í','&Icirc;':'Î','&icirc;':'î','&Igrave;':'Ì','&igrave;':'ì','&Iuml;':'Ï','&iuml;':'ï','&Oacute;':'Ó','&oacute;':'ó','&Ocirc;':'Ô','&ocirc;':'ô','&Ograve;':'Ò','&ograve;':'ò','&Oslash;':'Ø','&oslash;':'ø','&Otilde;':'Õ','&otilde;':'õ','&Ouml;':'Ö','&ouml;':'ö','&Uacute;':'Ú','&uacute;':'ú','&Ucirc;':'Û','&ucirc;':'û','&Ugrave;':'Ù','&ugrave;':'ù','&Uuml;':'Ü','&uuml;':'ü','&Ccedil;':'Ç','&ccedil;':'ç','&Ntilde;':'Ñ','&ntilde;':'ñ','&lt;':'<','&gt;':'>','&amp;':'&','&quot;':'"','&reg;':'®','&copy;':'©','&Yacute;':'Ý','&yacute;':'ý','&THORN;':'Þ','&thorn;':'þ','&szlig;':'ß','&ndash;':'-','&acute;':'D´','&acirc;':'â','&Acirc;':'Â','&ldquo;':'`','&rdquo;':'`','&ordf;':'ª','&nbsp;':'-','&rsquo;':"´",'&sup2;':'²','&sup3;':'³','&hellip;':'...','&ordm;':'º','&deg;':'°'}
    z = re.compile('&.*?;').findall(str(txt))
    keys = remove_repetidos(z)
    for name, age in x.items():
        txt = txt.replace(name,age)
    return txt

def series_episodios(url,name,iconimage):
    nam = []
    ur = []
    season = []
    url_link = url
    dual_lang = ''
    link  = getRequest2(url,'','')
    if '(Dublado / Legendado)</title>' in link:
        dual_lang = '(Dublado / Legendado)'
    try:
        link = link.replace('<p>&acute;','<p>')
        texto = re.findall('<p><img(.*?)</p',link,re.DOTALL)[0].replace('</p>','<br')
    except:
        try:
            link = re.findall('<div class=pm-video-thumb>(.*?)</div',link,re.DOTALL)[0].replace('\n','').replace('\r','')
        except:
            link = re.findall('<div class="pm-video-thumb">(.*?)</div',link,re.DOTALL)[0].replace('\n','').replace('\r','')
        link = re.compile('<a href="(.+?)"').findall(link)[0]
        link  = getRequest2(base_rc+link,'','')
        link = link.replace('<p>&acute;','<p>')
        texto = re.findall('<p><img(.*?)</p',link,re.DOTALL)[0]
    texto = re.sub('<span id=".+?"></span>','',texto)
    texto = texto.replace('<strong><a','<a')
    texto = texto.replace('</span></span>','</span>')
    texto = texto.replace('>Assistir</a></strong>','><strong>Assistir</strong></a>')
    texto = texto.replace('>Dublado</a></strong>','><strong>Dublado</strong></a>')
    texto = texto.replace('>Legendado</a></strong>','><strong>Legendado</strong></a>')
    texto = texto.replace('<span style="font-size: large;">','')
    texto = texto.replace('<span style="color: #38761d;"><strong>Indispon&iacute;vel</strong></span>','<a href="/404" target="_blank"><strong>(Indisponível)</strong></a>')
    texto = texto.replace('<strong><span style="color: red;">Em Breve</span></strong>','<a href="/404" target="_blank"><strong>(Indisponível)</strong></a>')
    texto = texto.replace('<span style="color: red;"><strong>Em Breve</strong></span>','<a href="/404" target="_blank"><strong>(Indisponível)</strong></a>')
    texto = texto.replace('<span style="color: #38761d;">Indispon&iacute;vel</span>','<a href="/404" target="_blank"><strong>(Indisponível)</strong></a>')
    texto = texto.replace('<strong><strong>','<strong>')
    texto = texto.replace('</strong></strong>','</strong>')
    texto = texto.replace('> <','><')
    texto = texto.replace('<br />','<br/>')
    texto = texto.replace('</span></span>','</span>')
    texto = texto.replace('</span></strong>','</strong></span>')
    texto = texto.replace('https://www.blogger.com','')
    texto = texto.replace('</span>&ordf;','&ordf;')
    texto = texto.replace('<span style="font-size: x-large;"><span style="font-size: x-large;">','<span style="font-size: x-large;">')
    texto = texto.replace('</strong></a></strong></strong></strong><br/><strong>','</strong></a><br/><strong>')
    texto = texto.replace('<strong><span style="font-size: x-large;">','<span style="font-size: x-large;"><strong>')
    if not '</strong></a><br/><strong>' in texto:
        texto = texto.replace('</strong></a>','</strong></a><br/>')
    if not '</strong></a></p>' in texto:
        texto = texto + '</strong></a><br/>'
    texto = texto.replace('</strong></a></strong></a>','</strong></a>')
    texto = texto.replace('</strong><a','<a').replace('<strong> - <a',' - <a')
    texto = editar_txt(texto)
    if '<strong>Legendado</strong>' in texto and '<strong>Dublado</strong>' in texto:
        dual_lang = '(Dublado / Legendado)'
    #img = re.compile('src="(.*?)"').findall(texto)[0]
    id = re.compile('<strong>(.*?)</a><br').findall(texto)
    if len(id) == 0:
        id = re.compile('<strong>(.*?)</a></strong><br').findall(texto)
    for i in id:
        if '</strong></span>' in i or '</span></strong>' in i or '</span> </strong>' in i:
            temporadas = re.compile('^(.+?)<').findall(i)[0]
            season.append(temporadas)
    #ADICIONAR EPS
    if len(season) > 1:
        for season_add in season:
            season_add = unicode(season_add).upper()
            if '(Dublado / Legendado)' in dual_lang:
                addDir('[B][COLOR white]%s[/COLOR][/B]'%season_add.encode('utf-8'),url_link,57,iconimage,'','','','',None)
            else:
                addDir('[B][COLOR white]%s[/COLOR][/B]'%season_add.encode('utf-8'),url_link,56,iconimage,'','','','',None)
            #xbmcgui.Dialog().ok(addon_name, str(len(season)))
    else:
        texto_correct = re.compile('<br/>.+?<a').findall(texto)
        for corrigir in texto_correct:
            if 'span>' in corrigir and '><br/>' in corrigir and '<a' in corrigir:
                txt = re.compile('><br/>.+?<a').findall(corrigir)[0]
                if '<br/>' in txt and not '<strong>' in txt and not '</strong>' in txt and '<a' in txt:
                    corrigir = txt.replace('><br/>','<br/>')
            if not '<strong>' in corrigir and not '</strong>' in corrigir and '<a' in corrigir:
                corrigir_replace = corrigir.replace('<br/>','<br/><strong>').replace('<a','</strong><a').replace('<strong> ','<strong>')
                texto = texto.replace(corrigir,corrigir_replace)
        id = re.compile('<strong>(.*?)</a><br').findall(texto)
        if len(id) == 0:
            id = re.compile('<strong>(.*?)</a></strong><br').findall(texto)
        for i in id:
            if '</strong></span>' in i or '</span></strong>' in i or '</span> </strong>' in i:
                temporadas = re.compile('^(.+?)<').findall(i)[0]
                season.append(temporadas)
            try:
                if '</strong></span>' in i or '</span></strong>' in i or '</span> </strong>' in i:
                    tt0 = i
                    tt = re.sub('<.+?>',' ',tt0)
                    tt = re.sub('\s+',' ',tt)
                else:
                    tt0 = i
                    tt = re.sub('<.+?>',' ',tt0)
                    tt = re.sub('\s+',' ',tt)
            except:
                tt0 = i
                tt = re.sub('<.+?>',' ',tt0)
                tt = re.sub('\s+',' ',tt)
            tt = tt.replace("'",'')
            tt = tt.replace('- Assistir','')
            if '(Indisponível)' in tt:
                tt = tt.replace('(Indisponível)','[COLOR orangered](Indisponível)[/COLOR]')
                nam.append(re.sub('\s/.+','',tt))
                ur.append(re.compile('href="(.*?)"').findall(tt0)[0])
            elif 'Dublado' in tt:
                nam.append(re.sub('\s/.+','',tt))
                ur.append(re.compile('href="(.*?)"').findall(tt0)[0])
            elif 'Legendado' in tt:
                nam.append(re.sub('\s\w+\s/','',tt))
                try:
                    ur.append(re.compile('href="(.*?)"').findall(tt0)[1])
                except:
                    ur.append(re.compile('href="(.*?)"').findall(tt0)[0])
            else:
                nam.append(tt)
                try:
                    ur.append(re.compile('href="(.*?)"').findall(tt0)[0])
                except:
                    ur.append(re.compile('href="(.*?)"').findall(tt0))
        match = list(zip(nam,ur))
        season_match = list(season)
        for name,url in match:
            name = name.replace(' - Dublado','').replace(' - Legendado','')
            desc = '[B]OS MELHORES CONTEÚDOS[CR]ACESSE: [COLOR orangered]REDECANAIS.CLOUD[/COLOR][/B]'
            for season_id in season_match:
                if season_id in name:
                    name = name.replace(season_id+' ','')
                    season_id = unicode(season_id).upper()
                    addLink('here','[B][COLOR orangered]%s[/COLOR][/B]'%season_id,iconimage,'','','','',True,None,'',0)
            try:
                name_novo = re.compile('(.+?) - (.+)').findall(name)[0]
                name1 = unicode(name_novo[0]).upper()
                name2 = unicode(name_novo[1]).upper()
                if 'EMBREVEOFF' in name2:
                    name2 = name2.replace('EMBREVEOFF','[COLOR orangered]OFF[/COLOR]')
                name = '[B]' + name1 + '[/B] - ' + name2
            except:
                name = unicode(name).upper()
            addLink(base_rc+url,'%s'%name,iconimage,'',desc,'','',True,None,'',0)

def series_episodios_show(url,idioma,iconimage):
    dica = ''
    texto = ''
    if '#' in url:
        temp_select = url.split('#')[1]
        url = url.split('#')[0]
    else:
        temp_select = idioma
    nam = []
    ur = []
    season = []
    link  = getRequest2(url,'','')
    idioma = idioma.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
    temp_select = temp_select.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
    try:
        link = link.replace('<p>&acute;','<p>')
        texto = re.findall('<p><img(.*?)</p',link,re.DOTALL)[0].replace('</p>','<br')
    except:
        try:
            link = re.findall('<div class=pm-video-thumb>(.*?)</div',link,re.DOTALL)[0].replace('\n','').replace('\r','')
        except:
            link = re.findall('<div class="pm-video-thumb">(.*?)</div',link,re.DOTALL)[0].replace('\n','').replace('\r','')
        link = re.compile('<a href="(.+?)"').findall(link)[0]
        link  = getRequest2(base_rc+link,'','')
        link = link.replace('<p>&acute;','<p>')
        texto = re.findall('<p><img(.*?)</p',link,re.DOTALL)[0]
    texto = re.sub('<span id=".+?"></span>','',texto)
    texto = texto.replace('<strong><a','<a')
    texto = texto.replace('</span></span>','</span>')
    texto = texto.replace('>Assistir</a></strong>','><strong>Assistir</strong></a>')
    texto = texto.replace('>Dublado</a></strong>','><strong>Dublado</strong></a>')
    texto = texto.replace('>Legendado</a></strong>','><strong>Legendado</strong></a>')
    texto = texto.replace('<span style="font-size: large;">','')
    texto = texto.replace('<span style="color: #38761d;"><strong>Indispon&iacute;vel</strong></span>','<a href="/404" target="_blank"><strong>(Indisponível)</strong></a>')
    texto = texto.replace('<strong><span style="color: red;">Em Breve</span></strong>','<a href="/404" target="_blank"><strong>(Indisponível)</strong></a>')
    texto = texto.replace('<span style="color: red;"><strong>Em Breve</strong></span>','<a href="/404" target="_blank"><strong>(Indisponível)</strong></a>')
    texto = texto.replace('<span style="color: #38761d;">Indispon&iacute;vel</span>','<a href="/404" target="_blank"><strong>(Indisponível)</strong></a>')
    texto = texto.replace('<strong><strong>','<strong>')
    texto = texto.replace('</strong></strong>','</strong>')
    texto = texto.replace('> <','><')
    texto = texto.replace('<br />','<br/>')
    texto = texto.replace('</span></span>','</span>')
    texto = texto.replace('</span></strong>','</strong></span>')
    texto = texto.replace('https://www.blogger.com','')
    texto = texto.replace('</span>&ordf;','&ordf;')
    texto = texto.replace('<span style="font-size: x-large;"><span style="font-size: x-large;">','<span style="font-size: x-large;">')
    texto = texto.replace('</strong></a></strong></strong></strong><br/><strong>','</strong></a><br/><strong>')
    texto = texto.replace('<strong><span style="font-size: x-large;">','<span style="font-size: x-large;"><strong>')
    if not '</strong></a><br/><strong>' in texto:
        texto = texto.replace('</strong></a>','</strong></a><br/>')
    if not '</strong></a></p>' in texto:
        texto = texto + '</strong></a><br/>'
    texto = texto.replace('</strong></a></strong></a>','</strong></a>')
    texto = texto.replace('</strong><a','<a').replace('<strong> - <a',' - <a').replace('<strong><a','<a')
    texto = texto.replace('</a></strong><br/>','</a><br/>')
    texto_correct = re.compile('<br/>.+?<a').findall(texto)
    for corrigir in texto_correct:
        if 'span>' in corrigir and '><br/>' in corrigir and '<a' in corrigir:
            txt = re.compile('><br/>.+?<a').findall(corrigir)[0]
            if '<br/>' in txt and not '<strong>' in txt and not '</strong>' in txt and '<a' in txt:
                corrigir = txt.replace('><br/>','<br/>')
        if not '<strong>' in corrigir and not '</strong>' in corrigir and '<a' in corrigir:
            corrigir_replace = corrigir.replace('<br/>','<br/><strong>').replace('<a','</strong><a').replace('<strong> ','<strong>')
            texto = texto.replace(corrigir,corrigir_replace)
    texto = editar_txt(texto)
    try:
        texto = re.compile('(<span style="font-size: x-large;"><strong>'+temp_select+'.+)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(texto)[0]
    except:
        pass
    #img = re.compile('src="(.*?)"').findall(texto)[0]
    id = re.compile('<strong>(.*?)</a><br').findall(texto)
    if len(id) == 0:
        id = re.compile('<strong>(.*?)</a></strong><br').findall(texto)
    for i in id:
        if '</strong></span>' in i or '</span></strong>' in i or '</span> </strong>' in i:
            temporadas = re.compile('^(.+?)<').findall(i)[0]
            season.append(temporadas)
        try:
            if '</strong></span>' in i or '</span></strong>' in i or '</span> </strong>' in i:
                tt0 = i
                tt = re.sub('<.+?>',' ',tt0)
                tt = re.sub('\s+',' ',tt)
            else:
                tt0 = i
                tt = re.sub('<.+?>',' ',tt0)
                tt = re.sub('\s+',' ',tt)
        except:
            tt0 = i
            tt = re.sub('<.+?>',' ',tt0)
            tt = re.sub('\s+',' ',tt)
        tt = tt.replace("'",'')
        tt = tt.replace('- Assistir','')
        if 'ASSISTIR DUBLADO' == idioma:
            if 'Dub' in tt: 
                nam.append(re.sub('\s/.+','',tt))
                ur.append(re.compile('href="(.*?)"').findall(tt0)[0])
            else:
                nam.append(tt)
                ur.append(re.compile('href="(.*?)"').findall(tt0)[0])
        elif 'ASSISTIR LEGENDADO' == idioma:
            if 'Leg' in tt:
                nam.append(re.sub('\s\w+\s/','',tt))
                try:
                    ur.append(re.compile('href="(.*?)"').findall(tt0)[1])
                except:
                    ur.append(re.compile('href="(.*?)"').findall(tt0)[0])
            else:
                nam.append(tt)
                ur.append(re.compile('href="(.*?)"').findall(tt0)[0])
        else:
            nam.append(tt)
            try:
                ur.append(re.compile('href="(.*?)"').findall(tt0)[0])
            except:
                pass#ur.append(re.compile('href="(.*?)"').findall(tt0))
    #ADICIONAR EPS
    match = list(zip(nam,ur))
    season_match = list(season)
    temp_name = ''
    for name,url in match:
        name = name.replace(' - Dublado','').replace(' - Legendado','')
        desc = '[B]OS MELHORES CONTEÚDOS[CR]ACESSE: [COLOR orangered]REDECANAIS.CLOUD[/COLOR][/B]'
        for season_id in season_match:
            if season_id in name:
                season_match.remove(season_id)
                name = name.replace(season_id+' ','')
                season_id = unicode(season_id).upper()
                temp_name = season_id
                if temp_name == temp_select:
                    addLink('here','[B][COLOR orangered]%s[/COLOR][/B]'%season_id,iconimage,'','','','',True,None,'',0)
        if temp_name == temp_select:
            try:
                name_novo = re.compile('(.+?) - (.+)').findall(name)[0]
                name1 = unicode(name_novo[0]).upper()
                name2 = unicode(name_novo[1]).upper()
                name = '[B]' + name1 + '[/B] - ' + name2
                if url == '/404':
                    name = name.replace('(INDISPONÍVEL)','[B][COLOR orangered](INDISPONÍVEL)[/COLOR][/B]')
            except:
                name = unicode(name).upper()
                if url == '/404':
                    name = name.replace('(INDISPONÍVEL)','[B][COLOR orangered](INDISPONÍVEL)[/COLOR][/B]')
            addLink(base_rc+url,'%s'%name,iconimage,'',desc,'','',True,None,'',0)

def dubladooulegendado(url_link,name,iconimage):
    name = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
    url_link = url_link + '#' + name
    desc = '[B][COLOR orangered]'+name+'[/COLOR][CR][CR]ESCOLHA EM QUAL IDIOMA VOCÊ PREFERE ASSISTIR![/B]'
    addDir('[B][COLOR white]ASSISTIR DUBLADO[/COLOR][/B]',url_link.encode('utf-8'),56,iconimage,'',desc,'','',None)
    addDir('[B][COLOR white]ASSISTIR LEGENDADO[/COLOR][/B]',url_link.encode('utf-8'),56,iconimage,'',desc,'','',None)

def netcine_filmes(name,url,fanart):
    base = getRequest2(url,'','')
    base = base.replace("#038;","").replace("&#192;","À").replace("&#193;","Á").replace("&#194;","Â").replace("&#195;","Ã").replace("&#196;","Ä").replace("&#224;","à").replace("&#225;","á").replace("&#226;","â").replace("&#227;","ã").replace("&#228;","ä").replace("&#200;","È").replace("&#201;","È").replace("&#202;","Ê").replace("&#203;","Ë").replace("&#232;","è").replace("&#233;","é").replace("&#234;","ê").replace("&#235;","ë").replace("&#204;","Ì").replace("&#205;","Í").replace("&#206;","Î").replace("&#207;","Ï").replace("&#236;","ì").replace("&#237;","í").replace("&#238;","î").replace("&#239;","ï").replace("&#211;","Ó").replace("&#243;","ó").replace("&#212;","Ô").replace("&#244;","ô").replace("&#244;","ô").replace("&#213;","Õ").replace("&#245;","õ").replace("&#217;","Ù").replace("&#218;","Ú").replace("&#219;","Û").replace("&#220;","Ü").replace("&#249;","ù").replace("&#250;","ú").replace("&#251;","û").replace("&#252;","ü").replace("&#199;","Ç").replace("&#231;","ç").replace("&#8230;","...").replace("&#038;","&").replace("&#8211;","–").replace("&#8217;","'").replace('&#147;','“').replace('&#148;','”').replace('&#34;','"').replace(" \n\n\t\t \n\t\t", "").replace("\n\t\t \n\t\t ", "").replace(r"\xc1","Á").replace(r"\xea","ê").replace(r"\xe7","ç").replace(r"\xe3","ã").replace(r"\xe9","é").replace(r"\xed","í").replace(r"\xe1","á").replace(r"\xe3","ó").replace(r"\xe0","à").replace(r"\xe0","à").replace(r"\xe2","â").replace("&#039;","'")
    texto = re.compile('<div.+?class="movie">.+?<img src="(.+?)".+?<a href="(.+?)">.+?<div.+?class="imdb">.+?</span>(.+?)</div>.+?<h2>(.+?)</h2>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)
    for img, url, imdb, name in texto:
        img = img.replace('-120x170','')
        imdb = imdb.replace(' ', '').replace('-', '')
        if not 'tvshows' in url:
            addLink(url,'[B]'+name.upper()+' - [COLOR mediumblue]'+imdb+'[/COLOR][/B]',img.encode('utf-8'),fanart.encode('utf-8'),'','','',True,None,'',0)
    #texto = base.replace('\n','').replace('\r','')
    page_next = re.compile("<span class='current'>.+?<a rel='nofollow' class='page larger' href='(.+?)'>(.+?)</a>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)
    for pagina, number in page_next:
        addDir('[B][COLOR mediumblue]PRÓXIMA PÁGINA %s[/COLOR][/B]'%number.encode('utf-8'),pagina.encode('utf-8'),59,'',fanart,'','','',None)

def netcine_series(name,url,fanart):
    base = getRequest2(url,'','')
    base = base.replace("#038;","").replace("&#192;","À").replace("&#193;","Á").replace("&#194;","Â").replace("&#195;","Ã").replace("&#196;","Ä").replace("&#224;","à").replace("&#225;","á").replace("&#226;","â").replace("&#227;","ã").replace("&#228;","ä").replace("&#200;","È").replace("&#201;","È").replace("&#202;","Ê").replace("&#203;","Ë").replace("&#232;","è").replace("&#233;","é").replace("&#234;","ê").replace("&#235;","ë").replace("&#204;","Ì").replace("&#205;","Í").replace("&#206;","Î").replace("&#207;","Ï").replace("&#236;","ì").replace("&#237;","í").replace("&#238;","î").replace("&#239;","ï").replace("&#211;","Ó").replace("&#243;","ó").replace("&#212;","Ô").replace("&#244;","ô").replace("&#244;","ô").replace("&#213;","Õ").replace("&#245;","õ").replace("&#217;","Ù").replace("&#218;","Ú").replace("&#219;","Û").replace("&#220;","Ü").replace("&#249;","ù").replace("&#250;","ú").replace("&#251;","û").replace("&#252;","ü").replace("&#199;","Ç").replace("&#231;","ç").replace("&#8230;","...").replace("&#038;","&").replace("&#8211;","–").replace("&#8217;","'").replace('&#147;','“').replace('&#148;','”').replace('&#34;','"').replace(" \n\n\t\t \n\t\t", "").replace("\n\t\t \n\t\t ", "").replace(r"\xc1","Á").replace(r"\xea","ê").replace(r"\xe7","ç").replace(r"\xe3","ã").replace(r"\xe9","é").replace(r"\xed","í").replace(r"\xe1","á").replace(r"\xe3","ó").replace(r"\xe0","à").replace(r"\xe0","à").replace(r"\xe2","â").replace("&#039;","'")
    texto = re.compile('<div.+?class="movie">.+?<img src="(.+?)".+?<a href="(.+?)">.+?<div.+?class="imdb">.+?</span>(.+?)</div>.+?<h2>(.+?)</h2>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)
    for img, url, imdb, name in texto:
        img = img.replace('-120x170','')
        imdb = imdb.replace(' ', '').replace('-', '')
        if 'tvshows' in url:
            addDir('[B]'+name.upper()+' - [COLOR orangered]'+imdb+'[/COLOR][/B]',url,17,img,fanart,'','','')
    #texto = base.replace('\n','').replace('\r','')
    page_next = re.compile("<span class='current'>.+?<a rel='nofollow' class='page larger' href='(.+?)'>(.+?)</a>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)
    for pagina, number in page_next:
        addDir('[B][COLOR orangered]PRÓXIMA PÁGINA %s[/COLOR][/B]'%number,pagina,17,'',fanart,'','','')

def netcine_series_list(name,url,iconimage,fanart):
    base = getRequest2(url,'','')
    base = base.replace("#038;","").replace("&#192;","À").replace("&#193;","Á").replace("&#194;","Â").replace("&#195;","Ã").replace("&#196;","Ä").replace("&#224;","à").replace("&#225;","á").replace("&#226;","â").replace("&#227;","ã").replace("&#228;","ä").replace("&#200;","È").replace("&#201;","È").replace("&#202;","Ê").replace("&#203;","Ë").replace("&#232;","è").replace("&#233;","é").replace("&#234;","ê").replace("&#235;","ë").replace("&#204;","Ì").replace("&#205;","Í").replace("&#206;","Î").replace("&#207;","Ï").replace("&#236;","ì").replace("&#237;","í").replace("&#238;","î").replace("&#239;","ï").replace("&#211;","Ó").replace("&#243;","ó").replace("&#212;","Ô").replace("&#244;","ô").replace("&#244;","ô").replace("&#213;","Õ").replace("&#245;","õ").replace("&#217;","Ù").replace("&#218;","Ú").replace("&#219;","Û").replace("&#220;","Ü").replace("&#249;","ù").replace("&#250;","ú").replace("&#251;","û").replace("&#252;","ü").replace("&#199;","Ç").replace("&#231;","ç").replace("&#8230;","...").replace("&#038;","&").replace("&#8211;","–").replace("&#8217;","'").replace('&#147;','“').replace('&#148;','”').replace('&#34;','"').replace(" \n\n\t\t \n\t\t", "").replace("\n\t\t \n\t\t ", "").replace(r"\xc1","Á").replace(r"\xea","ê").replace(r"\xe7","ç").replace(r"\xe3","ã").replace(r"\xe9","é").replace(r"\xed","í").replace(r"\xe1","á").replace(r"\xe3","ó").replace(r"\xe0","à").replace(r"\xe0","à").replace(r"\xe2","â").replace("&#039;","'")
    texto = re.compile("<li.+?class='has-sub'><a.+?href='#'><span>.+?</b> (.+?)</span></a>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)
    #sinopse
    sinopsebase = base.replace('<p><texto class="margin_30t margin_20b"></p>','').replace('<p style="text-align: justify;">','<p>')
    Sinopse = re.compile('<h2>Synopsis</h2>.+?<p>(.+?)</p>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(sinopsebase)
    if Sinopse !=[]:
        sinopse = str(Sinopse[0])
    else:
        sinopse = '[B]OS MELHORES CONTEÚDOS[CR]ACESSE: [COLOR orangered]NETCINE.BIZ[/COLOR][/B]'
    for season in texto:
        season_select = season
        season = season.replace('Temporada ','')
        season = season + 'ª Temporada'
        season = season.upper()
        addDir('[B]'+str(season)+'[/B]',url+'#'+season_select,61,iconimage,fanart,sinopse,'','',None)

def netcine_series_show(name,url,iconimage,fanart):
    if '#' in url:
        temp = url.split('#')[1]
        url = url.split('#')[0]
    base = getRequest2(url,'','')
    base = base.replace("#038;","").replace("&#192;","À").replace("&#193;","Á").replace("&#194;","Â").replace("&#195;","Ã").replace("&#196;","Ä").replace("&#224;","à").replace("&#225;","á").replace("&#226;","â").replace("&#227;","ã").replace("&#228;","ä").replace("&#200;","È").replace("&#201;","È").replace("&#202;","Ê").replace("&#203;","Ë").replace("&#232;","è").replace("&#233;","é").replace("&#234;","ê").replace("&#235;","ë").replace("&#204;","Ì").replace("&#205;","Í").replace("&#206;","Î").replace("&#207;","Ï").replace("&#236;","ì").replace("&#237;","í").replace("&#238;","î").replace("&#239;","ï").replace("&#211;","Ó").replace("&#243;","ó").replace("&#212;","Ô").replace("&#244;","ô").replace("&#244;","ô").replace("&#213;","Õ").replace("&#245;","õ").replace("&#217;","Ù").replace("&#218;","Ú").replace("&#219;","Û").replace("&#220;","Ü").replace("&#249;","ù").replace("&#250;","ú").replace("&#251;","û").replace("&#252;","ü").replace("&#199;","Ç").replace("&#231;","ç").replace("&#8230;","...").replace("&#038;","&").replace("&#8211;","–").replace("&#8217;","'").replace('&#147;','“').replace('&#148;','”').replace('&#34;','"').replace(" \n\n\t\t \n\t\t", "").replace("\n\t\t \n\t\t ", "").replace(r"\xc1","Á").replace(r"\xea","ê").replace(r"\xe7","ç").replace(r"\xe3","ã").replace(r"\xe9","é").replace(r"\xed","í").replace(r"\xe1","á").replace(r"\xe3","ó").replace(r"\xe0","à").replace(r"\xe0","à").replace(r"\xe2","â").replace("&#039;","'")
    base = base.replace('\n','').replace('\r','').replace("='",'="').replace("'>",'">')
    texto = re.compile('<li class="has-sub"><a href="#"><span><b class="icon-bars"><\/b> '+temp+'<\/span><\/a>(.+?)<\/ul>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
    texto = re.compile('<li><a href="(.+?)".+?class="datex">(.+?)</span>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(texto)
    #season_add
    addLink('here','[COLOR orangered]'+name+'[/COLOR]',iconimage.encode('utf-8'),fanart.encode('utf-8'),description,'','',True,None,'',0)
    for link, title in texto:
        episodio = re.sub('(.+?) - ', '', title)
        addLink(link.encode('utf-8'),'[B]EPISÓDIO - '+episodio+'[/B]',iconimage.encode('utf-8'),fanart.encode('utf-8'),description,'','',True,None,'',0)

def pornhub(name,url,fanart):
    base_url = 'https://pt.pornhub.com'
    if not 'https://pt.pornhub.com' in url:
        url = base_url+url
    base = getRequest(url,'','')
    link = base.replace('\n','').replace('\r','').replace('data-thumb_url = "','data-thumb_url="')
    texto = re.findall('<div class="nf-videos">(.+)</div>',link,re.DOTALL)[0]
    nome = re.compile('<div class="preloadLine".+?href="(.+?)".+?title="(.+?)".+?data-thumb_url="(.+?)"').findall(texto)
    for url, title, thumb in nome:
        if not 'javascript:void(0)' in url:
            title = title.replace("&#039;","'").upper()
            addLink(base_url+url,'[B]'+title+'[/B]',thumb.encode('utf-8'),fanart.encode('utf-8'),'','','',True,None,'',0)
    #PageNavigation
    page = re.compile('<li class="page_current.+?<li class="page_number"><a class="greyButton" href="(.+?)">(.+?)</a></li>').findall(link)
    #page = re.findall('',base,re.DOTALL)[0]
    for url, page_id in page:
        url = url.replace('&amp;','&')
        url = base_url + url
        addDir('[B][COLOR orangered]PRÓXIMA PÁGINA %s[/COLOR][/B]'%page_id.encode('utf-8'),url.encode('utf-8'),58,'',fanart,'','','',None)

try:
    if 'PESQUISE POR FILMES' in xbmc.getInfoLabel('ListItem.Label'):
        global pesquisa_desativar
        global search
        pesquisa_desativar = 'false'
        search = ''
except:
    pass

def pesquisar_filmes():
    global pesquisa_desativar
    global search
    if pesquisa_desativar == 'false':
        if search == '':
            keyb = xbmc.Keyboard('', 'PESQUISE O SEU FILME FAVORITO')
            keyb.doModal()
            if (keyb.isConfirmed()):
                search = keyb.getText()
                search = remover_acentos(search)
                search = search.lower()
                if search == '' or search == ' ' or search == '  ':
                    pesquisa_desativar = 'false'
                    search = ''
                    pesquisar_filmes()
                    exit()
                pesquisa_desativar = 'true'
                pesquisa_final()
            else:
                pesquisa_desativar = 'false'
                search = ''
                exit()
    else:
        pesquisa_final()

def pesquisa_final():
    try:
        link = ''
        url = base_search_rc
        for page in range(1,28):
            link += getRequest2(url%(page),'','')
        link = link.replace('\n','').replace('\r','')
        nome = re.compile('<title>(.+?)</title><link>(.+?)</link><thumbnail>(.+?)</thumbnail>.+?<info>(.+?)</info><date>(.+?)</date>').findall(link)
        find_id = '0'
        for title, url, thumb, info, date in nome:
            title2 = title.replace('[B][COLOR white]','').replace('[/COLOR][/B]','').replace(' [COLOR orangered](LEG)[/COLOR]','')
            title2 = remover_acentos(title2)
            title2 = title2.lower()
            if search in title2 and '.mp4' in url:
                addLink(url,title,thumb,thumb,info,'',date,True,None,'',0)
                find_id = '1'
        if find_id == '0':
            notify('[B][COLOR orangered]'+search+'[/COLOR] não encontrado![/B]')
            exit()
    except:
        pass

from unicodedata import normalize

def remover_acentos(txt, codif='utf-8'):
    return normalize('NFKD', txt.decode(codif)).encode('ASCII', 'ignore')

def parental_password():
    try:
        addonID = xbmcaddon.Addon().getAddonInfo('id')
        addon_data_path = xbmc.translatePath(os.path.join('special://home/userdata/addon_data', addonID))
        if os.path.exists(addon_data_path)==False:
            os.mkdir(addon_data_path)
        xbmc.sleep(7)
        #Path = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
        #arquivo = os.path.join(Path, "password.txt")
        arquivo = os.path.join(addon_data_path, "pass.txt")
        exists = os.path.isfile(arquivo)
        if exists == False:
            password = '0000'
            p_encoded = base64.b64encode(password.encode()).decode('utf-8')
            p_file = open(arquivo,'w')
            p_file.write(p_encoded)
            p_file.close()
    except:
        pass

def updateEPG():
    try:
        Path = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
        arquivo = os.path.join(Path, "epgbr.xml")
        exists = os.path.isfile(arquivo)
        uversao = urllib2.urlopen('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/version_epg.txt').read()
        uversao = re.compile('[a-zA-Z\.\d]+').findall(uversao)[0]
        if exists == False:
            downloadEPG(uversao)
        else:
            if epgLast == "":
                downloadEPG(uversao)
            else:
                if uversao != epgLast:
                    downloadEPG(uversao)
    except:
        notify('[COLOR red]Erro ao atualizar EPG![/COLOR]')

def downloadEPG(data):
    try:
        import downloader_epg
        Path = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
        arquivo = os.path.join(Path, "epgbr.xml")
        exists = os.path.isfile(arquivo)
        dp = xbmcgui.DialogProgress()
        dp.create('Baixando EPG...','Por favor aguarde...')
        if exists:
            try:
                os.remove(arquivo)
            except:
                pass
        #downloader_epg.download(base64.b64decode(epg_url), arquivo, dp)
        downloader_epg.download(epg_url, arquivo, dp)
        xbmc.sleep(100)
        #data = datetime.now()
        #data = data.strftime("%d.%m.%y")
        xbmcaddon.Addon().setSetting("epg_last", data)
        CleanEPG()
    except:
        notify('[COLOR red]Erro ao atualizar EPG![/COLOR]')

def CleanEPG():
    Path = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
    arquivo = os.path.join(Path, "epgbr.xml")
    try:
        with open(arquivo, 'r') as content_file:
            content = content_file.read()
            for dias in range(1, 8):
                days = datetime.now() - timedelta(days=dias)
                days = days.strftime('%Y%m%d')
                if content.find(days):
                    content = re.sub('<programme.+stop="'+days+'.+<.programme>', '', content)
                if dias == 7:
                    content = content.replace('\n', '').replace('\r','')
                    content = content.replace('<programme start=', '\n' +'<programme start=')
            file = open(arquivo,'w')
            file.write(content)
            file.close()
    except:
        addon_log('Fix EPG Fail')

def epgParseData():
    try:
        Path = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
        arquivo = os.path.join(Path, "epgbr.xml").decode("utf8")
        xml = ET.parse(arquivo)
        return xml.getroot()
    except:
        notify('[COLOR red]Erro ao carregar EPG![/COLOR]')
        return None

def getID_EPG(name):
    name = name.encode('utf-8','ignore')
    if re.search("A&E",str(name),re.IGNORECASE):
        channel_id = 'Ae.br'
    elif re.search("AMC",str(name),re.IGNORECASE):
        channel_id = 'Amc.br'
    elif re.search("Animal Planet",str(name),re.IGNORECASE):
        channel_id = 'Animalplanet.br'
    elif re.search("Arte 1",str(name),re.IGNORECASE):
        channel_id = 'Arte1.br'
    elif re.search("AXN",str(name),re.IGNORECASE):
        channel_id = 'Axn.br'
    elif re.search("Baby TV",str(name),re.IGNORECASE) or re.search("BabyTV",str(name),re.IGNORECASE):
        channel_id = 'BabyTV.br'
    elif re.search("Band",str(name),re.IGNORECASE) and not re.search("Band News",str(name),re.IGNORECASE) and not re.search("Band Sports",str(name),re.IGNORECASE):
        channel_id = 'BandRede.br'
    elif re.search("Band News",str(name),re.IGNORECASE):
        channel_id = 'Bandnews.br'
    elif re.search("Band Sports",str(name),re.IGNORECASE):
        channel_id = 'Bandsportshd.br'
    elif re.search("BIS",str(name),re.IGNORECASE):
        channel_id = 'Bishd.br'
    elif re.search("Boomerang",str(name),re.IGNORECASE):
        channel_id = 'Boomerang.br'
    elif re.search("Canal Brasil",str(name),re.IGNORECASE):
        channel_id = 'Canalbrasil.br'
    elif re.search("Cancao Nova",str(name),re.IGNORECASE) or re.search("Canção Nova",str(name),re.IGNORECASE):
        channel_id = 'CancaoNova.br'
    elif re.search("Cartoon Network",str(name),re.IGNORECASE):
        channel_id = 'Cartoonnetwork.br'
    elif re.search("Cinemax",str(name),re.IGNORECASE):
        channel_id = 'Cinemax.br'
    elif re.search("Combate",str(name),re.IGNORECASE):
        channel_id = 'Combatehd.br'
    elif re.search("Comedy Central",str(name),re.IGNORECASE):
        channel_id = 'Comedycentral.br'
    elif re.search("Cultura",str(name),re.IGNORECASE):
        channel_id = 'Tvcultura.br'
    elif re.search("Curta!",str(name),re.IGNORECASE) or re.search("Curta",str(name),re.IGNORECASE):
        channel_id = 'Curta.br'
    elif re.search("Discovery Channel",str(name),re.IGNORECASE):
        channel_id = 'Discovery.br'
    elif re.search("Discovery Civilization",str(name),re.IGNORECASE):
        channel_id = 'DiscoveryCivilization.br'
    elif re.search("Discovery Home & Health",str(name),re.IGNORECASE) or re.search("Discovery H&H",str(name),re.IGNORECASE):
        channel_id = 'Homehealth.br'
    elif re.search("Discovery Kids",str(name),re.IGNORECASE):
        channel_id = 'Discoverykids.br'
    elif re.search("Discovery Science",str(name),re.IGNORECASE):
        channel_id = 'DiscoveryScience.br'
    elif re.search("Discovery Theater",str(name),re.IGNORECASE):
        channel_id = 'Hdtheater.br'
    elif re.search("Discovery Turbo",str(name),re.IGNORECASE):
        channel_id = 'Discturbohd.br'
    elif re.search("Discovery World",str(name),re.IGNORECASE):
        channel_id = 'Discoveryworldhd.br'
    elif re.search("Disney Channel",str(name),re.IGNORECASE):
        channel_id = 'Disneychannel.br'
    elif re.search("Disney Junior",str(name),re.IGNORECASE) or re.search("Disney Jr",str(name),re.IGNORECASE):
        channel_id = 'Disneyjrhd.br'
    elif re.search("Disney XD",str(name),re.IGNORECASE):
        channel_id = 'Disneyxd.br'
    elif re.search("Disney",str(name),re.IGNORECASE):
        channel_id = 'Disneychannel.br'
    elif re.search("E!",str(name),re.IGNORECASE):
        channel_id = 'E.br'
    elif re.search("E!",str(name),re.IGNORECASE):
        channel_id = 'E.br'
    elif re.search("ESPN",str(name),re.IGNORECASE) and not re.search("ESPN 2",str(name),re.IGNORECASE) and not re.search("ESPN Brasil",str(name),re.IGNORECASE) and not re.search("ESPN Extra",str(name),re.IGNORECASE):
        channel_id = 'ESPNInternational.br'
    elif re.search("ESPN 2",str(name),re.IGNORECASE):
        channel_id = 'ESPN+.br'
    elif re.search("ESPN Brasil",str(name),re.IGNORECASE):
        channel_id = 'Espnbrasil.br'
    elif re.search("ESPN Extra",str(name),re.IGNORECASE):
        channel_id = 'Espnextra.br'
    elif re.search("FishTV",str(name),re.IGNORECASE) or re.search("Fish TV",str(name),re.IGNORECASE):
        channel_id = 'Fishtv.br'
    elif re.search("Food Network",str(name),re.IGNORECASE):
        channel_id = 'Foodnetworkhd.br'
    elif re.search("Star Channel",str(name),re.IGNORECASE) or re.search("Fox",str(name),re.IGNORECASE) and not re.search("Fox Life",str(name),re.IGNORECASE) and not re.search("FOX Premium 1",str(name),re.IGNORECASE) and not re.search("FOX Premium 2",str(name),re.IGNORECASE) and not re.search("Fox Sports",str(name),re.IGNORECASE) and not re.search("Fox Sports 2",str(name),re.IGNORECASE) and not re.search("Fox 25",str(name),re.IGNORECASE) and not re.search("News",str(name),re.IGNORECASE):
        channel_id = 'Fox.br'
    elif re.search("Star Life",str(name),re.IGNORECASE) or re.search("Fox Life",str(name),re.IGNORECASE):
        channel_id = 'Foxlife.br'
    elif re.search("Star Hits 1",str(name),re.IGNORECASE) or re.search("FOX Premium 1",str(name),re.IGNORECASE):
        channel_id = 'Foxpremium1.br'
    elif re.search("Star Hits 2",str(name),re.IGNORECASE) or re.search("FOX Premium 2",str(name),re.IGNORECASE):
        channel_id = 'Foxpremium2.br'
    elif re.search("Fox Sports",str(name),re.IGNORECASE) and not re.search("Fox Sports 2",str(name),re.IGNORECASE):
        channel_id = 'Foxsports.br'
    elif re.search("Fox Sports 2",str(name),re.IGNORECASE):
        channel_id = 'Foxsports2.br'
    elif re.search("Futura",str(name),re.IGNORECASE):
        channel_id = 'Futura.br'
    elif re.search("FX",str(name),re.IGNORECASE) and not re.search("US",str(name),re.IGNORECASE):
        channel_id = 'Fx.br'
    elif re.search("Film & Arts",str(name),re.IGNORECASE):
        channel_id = 'FilmArts.br'
    elif re.search("Globo Brasilia",str(name),re.IGNORECASE) or re.search("Globo Brasília",str(name),re.IGNORECASE):
        channel_id = 'GloboBrasilia.br'
    elif re.search("Globo Campinas",str(name),re.IGNORECASE) or re.search("Globo EPTV Campinas",str(name),re.IGNORECASE):
        channel_id = 'GloboEPTVCampinas.br'
    elif re.search("Globo Minas",str(name),re.IGNORECASE):
        channel_id = 'Globominas.br'
    elif re.search("Globo News",str(name),re.IGNORECASE):
        channel_id = 'Globonews.br'
    elif re.search("Globo RBS TV Poa",str(name),re.IGNORECASE) or re.search("RBS TV",str(name),re.IGNORECASE) or re.search("RBS Porto Alegre",str(name),re.IGNORECASE):
        channel_id = 'GloboPortoAlegre.br'
    elif re.search("Globo RJ",str(name),re.IGNORECASE):
        channel_id = 'Globorj.br'
    elif re.search("Globo SP",str(name),re.IGNORECASE) or re.search("Globo",str(name),re.IGNORECASE) >= 0 and not re.search("Mais Globosat",str(name),re.IGNORECASE) and not re.search("Globo Nordeste",str(name),re.IGNORECASE):
        channel_id = 'Globosp.br'
    elif re.search("Globo TV Anhanguera",str(name),re.IGNORECASE):
        channel_id = 'GloboAnhangueraGoias.br'
    elif re.search("Globo TV Bahia",str(name),re.IGNORECASE):
        channel_id = 'Tvbahia.br'
    elif re.search("Globo TV Tem Bauru",str(name),re.IGNORECASE) or re.search("TV Tem Bauru",str(name),re.IGNORECASE) or re.search("TVTem Bauru",str(name),re.IGNORECASE):
        channel_id = 'Tvtembauru.br'
    elif re.search("Globo TV Tribuna",str(name),re.IGNORECASE) or re.search("TV Tribuna",str(name),re.IGNORECASE):
        channel_id = 'Tvtribuna.br'
    elif re.search("Globo TV Vanguarda",str(name),re.IGNORECASE) or re.search("TV Vanguarda",str(name),re.IGNORECASE):
        channel_id = 'Vangsaojchd.br'
    elif re.search("Globo Inter TV Alto Litoral",str(name),re.IGNORECASE):
        channel_id = 'Inttvaltolit.br'
    elif re.search("Globo Inter TV Grande Minas",str(name),re.IGNORECASE) or re.search("Globo Inter TV Minas",str(name),re.IGNORECASE):
        channel_id = 'Intertvgminas.br'
    elif re.search("Globo NSC Florianopolis",str(name),re.IGNORECASE):
        channel_id = 'NSCTV.br'
    elif re.search("Globo Nordeste",str(name),re.IGNORECASE):
        channel_id = 'Globorecife.br'
    elif re.search("Globo RPC Parana",str(name),re.IGNORECASE) or re.search("Globo RPC Curitiba",str(name),re.IGNORECASE):
        channel_id = 'Rpccuritiba.br'
    elif re.search("Gloob",str(name),re.IGNORECASE) and not re.search("Gloobinho",str(name),re.IGNORECASE):
        channel_id = 'Gloob.br'
    elif re.search("Gloobinho",str(name),re.IGNORECASE):
        channel_id = 'Gloobinho.br'
    elif re.search("GNT",str(name),re.IGNORECASE):
        channel_id = 'Gnt.br'
    elif re.search("HBO",str(name),re.IGNORECASE) and not re.search("HBO 2",str(name),re.IGNORECASE) and not re.search("HBO Family",str(name),re.IGNORECASE) and not re.search("HBO Plus",str(name),re.IGNORECASE) and not re.search("HBO Signature",str(name),re.IGNORECASE) and not re.search("HBO Mundi",str(name),re.IGNORECASE) and not re.search("HBO Xtreme",str(name),re.IGNORECASE) and not re.search("HBO Pop",str(name),re.IGNORECASE):
        channel_id = 'Hbo.br'
    elif re.search("HBO 2",str(name),re.IGNORECASE):
        channel_id = 'Hbo2.br'
    elif re.search("HBO Family",str(name),re.IGNORECASE):
        channel_id = 'Hbofamily.br'
    elif re.search("HBO Plus",str(name),re.IGNORECASE):
        channel_id = 'Hboplus.br'
    elif re.search("HBO Signature",str(name),re.IGNORECASE):
        channel_id = 'Hbosignature.br'
    elif re.search("HBO Mundi",str(name),re.IGNORECASE):
        channel_id = 'Max.br'
    elif re.search("HBO Xtreme",str(name),re.IGNORECASE):
        channel_id = 'Maxprime.br'
    elif re.search("HBO Pop",str(name),re.IGNORECASE):
        channel_id = 'Maxup.br'
    elif re.search("History",str(name),re.IGNORECASE):
        channel_id = 'Historychannel.br'
    elif re.search("ID",str(name),re.IGNORECASE) and not re.search("Nat Geo Kids",str(name),re.IGNORECASE):
        channel_id = 'Investigacaodiscoveryid.br'
    elif re.search("Lifetime",str(name),re.IGNORECASE):
        channel_id = 'Lifetime.br'
    elif re.search("Mais GloboSat",str(name),re.IGNORECASE):
        channel_id = '+globosat.br'
    elif re.search("Max",str(name),re.IGNORECASE) and not re.search("Max Prime",str(name),re.IGNORECASE) and not re.search("Max UP",str(name),re.IGNORECASE):
        channel_id = 'Max.br'
    elif re.search("Max Prime",str(name),re.IGNORECASE):
        channel_id = 'Maxprime.br'
    elif re.search("Max UP",str(name),re.IGNORECASE):
        channel_id = 'Maxup.br'
    elif re.search("Megapix",str(name),re.IGNORECASE):
        channel_id = 'Megapix.br'
    elif re.search("MTV",str(name),re.IGNORECASE) and not re.search("US",str(name),re.IGNORECASE):
        channel_id = 'Mtv.br'
    elif re.search("Multishow",str(name),re.IGNORECASE):
        channel_id = 'Multishow.br'
    elif re.search("Nat Geo Kids",str(name),re.IGNORECASE) and not re.search("Nat Geo Wild",str(name),re.IGNORECASE) and not re.search("National Geographic",str(name),re.IGNORECASE):
        channel_id = 'Natgeokids.br'
    elif re.search("Nat Geo Wild",str(name),re.IGNORECASE):
        channel_id = 'Natgeowildhd.br'
    elif re.search("Nat Geo",str(name),re.IGNORECASE):
        channel_id = 'Nationalgeographic.br'
    elif re.search("Nick",str(name),re.IGNORECASE) and not re.search("Nick Jr",str(name),re.IGNORECASE) and not re.search("Nick Junior",str(name),re.IGNORECASE):
        channel_id = 'Nickelodeon.br'
    elif re.search("Nick Jr",str(name),re.IGNORECASE):
        channel_id = 'NickJr.br'
    elif re.search("Off",str(name),re.IGNORECASE) and not re.search("CNN",str(name),re.IGNORECASE):
        channel_id = 'Off.br'
    elif re.search("PlayBoy",str(name),re.IGNORECASE):
        channel_id = 'Playboytv.br'
    elif re.search("Paramount",str(name),re.IGNORECASE):
        channel_id = 'Paramounthd.br'
    elif re.search("Paramount",str(name),re.IGNORECASE):
        channel_id = 'Playtv.br'
    elif re.search("Premiere Clube",str(name),re.IGNORECASE):
        channel_id = 'Premierefchd.br'
    elif re.search("Prime Box",str(name),re.IGNORECASE):
        channel_id = 'Primeboxbrazil.br'
    elif re.search("Ra Tim Bum",str(name),re.IGNORECASE):
        channel_id = 'Tvratimbum.br'
    elif re.search("Record News",str(name),re.IGNORECASE):
        channel_id = 'Recordnews.br'
    elif re.search("Record News",str(name),re.IGNORECASE):
        channel_id = 'Recordnews.br'
    elif re.search("Record",str(name),re.IGNORECASE) or re.search("Record SP",str(name),re.IGNORECASE):
        channel_id = 'Rederecord.br'
    elif re.search("Rede Brasil",str(name),re.IGNORECASE):
        channel_id = 'Redebrasil.br'
    elif re.search("Rede TV",str(name),re.IGNORECASE) or re.search("RedeTV",str(name),re.IGNORECASE):
        channel_id = 'Redetv.br'
    elif re.search("Rede Vida",str(name),re.IGNORECASE):
        channel_id = 'Redevida.br'
    elif re.search("SBT",str(name),re.IGNORECASE):
        channel_id = 'Sbt.br'
    elif re.search("Sexy Hot",str(name),re.IGNORECASE) or re.search("SexyHot",str(name),re.IGNORECASE):
        channel_id = 'Sexyhot.br'
    elif re.search("Sony",str(name),re.IGNORECASE):
        channel_id = 'Sony.br'
    elif re.search("Space",str(name),re.IGNORECASE):
        channel_id = 'Space.br'
    elif re.search("Sportv",str(name),re.IGNORECASE) and not re.search("Sportv 2",str(name),re.IGNORECASE) and not re.search("Sportv 3",str(name),re.IGNORECASE):
        channel_id = 'Sportv.br'
    elif re.search("Sportv 2",str(name),re.IGNORECASE):
        channel_id = 'Sportv2.br'
    elif re.search("Sportv 3",str(name),re.IGNORECASE):
        channel_id = 'Sportv3.br'
    elif re.search("Studio Universal",str(name),re.IGNORECASE):
        channel_id = 'Studiouniversal.br'
    elif re.search("Universal Channel",str(name),re.IGNORECASE):
        channel_id = 'Universalchannel.br'
    elif re.search("Syfy",str(name),re.IGNORECASE):
        channel_id = 'Syfy.br'
    elif re.search("TBS",str(name),re.IGNORECASE):
        channel_id = 'Tbs.br'
    elif re.search("TCM",str(name),re.IGNORECASE):
        channel_id = 'Tcm.br'
    elif re.search("Telecine Action",str(name),re.IGNORECASE):
        channel_id = 'Tcaction.br'
    elif re.search("Telecine Action",str(name),re.IGNORECASE):
        channel_id = 'Tcaction.br'
    elif re.search("Telecine Cult",str(name),re.IGNORECASE):
        channel_id = 'Tccult.br'
    elif re.search("Telecine Fun",str(name),re.IGNORECASE):
        channel_id = 'Tcfun.br'
    elif re.search("Telecine Pipoca",str(name),re.IGNORECASE):
        channel_id = 'Tcpipoca.br'
    elif re.search("Telecine Premium",str(name),re.IGNORECASE):
        channel_id = 'Tcpremium.br'
    elif re.search("Telecine Touch",str(name),re.IGNORECASE):
        channel_id = 'Tctouch.br'
    elif re.search("TLC",str(name),re.IGNORECASE):
        channel_id = 'Tlc.br'
    elif re.search("TNT",str(name),re.IGNORECASE) and not re.search("TNT SÉRIE",str(name),re.IGNORECASE):
        channel_id = 'Tnt.br'
    elif re.search("TNT SÉRIE",str(name),re.IGNORECASE):
        channel_id = 'TNTSerie.br'
    elif re.search("Tooncast",str(name),re.IGNORECASE):
        channel_id = 'Tooncast.br'
    elif re.search("truTV",str(name),re.IGNORECASE):
        channel_id = 'Trutv.br'
    elif re.search("TV Gazeta",str(name),re.IGNORECASE):
        channel_id = 'TVGazeta.br'
    elif re.search("VH1",str(name),re.IGNORECASE) and not re.search("VH1 Megahits",str(name),re.IGNORECASE):
        channel_id = 'VH1HD.br'
    elif re.search("VH1 Megahits",str(name),re.IGNORECASE):
        channel_id = 'VH1MegaHits.br'
    elif re.search("Viva",str(name),re.IGNORECASE):
        channel_id = 'Viva.br'
    elif re.search("Warner Channel",str(name),re.IGNORECASE) or re.search("Warner",str(name),re.IGNORECASE):
        channel_id = 'Warnerchannel.br'
    elif re.search("WooHoo",str(name),re.IGNORECASE):
        channel_id = 'Woohoo.br'
    elif re.search("Zoomoo",str(name),re.IGNORECASE):
        channel_id = 'Zoomoo.br'
    elif re.search("CNN Brasil",str(name),re.IGNORECASE):
        channel_id = 'Cnnbrasil.br'
    elif re.search("H2",str(name),re.IGNORECASE):
        channel_id = 'H2.br'
    elif re.search("HGTV",str(name),re.IGNORECASE):
        channel_id = 'Hgtv.br'
    else:
        channel_id = ''
    return channel_id

def getEPG(root,chan):
    try:
        programas = root.findall("./programme[@channel='"+chan+"']")
        agora = datetime.now()
        agora = agora.strftime("%Y%m%d%H%M%S")
        proximo = datetime.now()
        proximo = proximo.strftime("%Y%m%d%H%M%S")
        for item in programas:
            start = item.get('start')[:-6]
            stop = item.get('stop')[:-6]
            if int(start) <= int(agora) < int(stop):
                proximo = stop
                epg = ' - [B][COLOR white]' + item.find('title').text + '[/COLOR][/B]' + '[CR][COLOR orangered][B]' + start[8:-4] + ':' + start[10:-2] + ' - ' + stop[8:-4] + ':' + stop[10:-2] + '[/B][/COLOR]'
                desc = item.find('desc')
                if desc is None:
                    sinopse = '[CR][CR]Nenhuma informação disponível'
                else:
                    sinopse = '[CR][CR]' + desc.text
                desc_epg = epg + sinopse
            if int(start) <= int(proximo) < int(stop):
                epg2 = '[B][COLOR white]' + item.find('title').text + '[/COLOR][/B]' + '[CR][COLOR orangered][B]' + start[8:-4] + ':' + start[10:-2] + ' - ' + stop[8:-4] + ':' + stop[10:-2] + '[/B][/COLOR]'
                desc = item.find('desc')
                epg_show = epg.replace(' - [B][COLOR white]','[B][COLOR white]')
                if desc is None:
                    sinopse2 = '[CR][CR]Nenhuma informação disponível'
                else:
                    sinopse2 = '[CR][CR]' + desc.text
                desc_epg = epg_show + sinopse + '[CR][CR]' + epg2+sinopse2
        return epg, desc_epg;
    except:
        epg = ''
        desc_epg = ''
        return epg, desc_epg;

def parse_regex(reg_item):
                try:
                    regexs = {}
                    for i in reg_item:
                        regexs[i('name')[0].string] = {}
                        regexs[i('name')[0].string]['name']=i('name')[0].string
                        #regexs[i('name')[0].string]['expres'] = i('expres')[0].string
                        try:
                            regexs[i('name')[0].string]['expres'] = i('expres')[0].string
                            if not regexs[i('name')[0].string]['expres']:
                                regexs[i('name')[0].string]['expres']=''
                        except:
                            addon_log("Regex: -- No Referer --")
                        regexs[i('name')[0].string]['page'] = i('page')[0].string
                        try:
                            regexs[i('name')[0].string]['referer'] = i('referer')[0].string
                        except:
                            addon_log("Regex: -- No Referer --")
                        try:
                            regexs[i('name')[0].string]['connection'] = i('connection')[0].string
                        except:
                            addon_log("Regex: -- No connection --")
                        try:
                            regexs[i('name')[0].string]['notplayable'] = i('notplayable')[0].string
                        except:
                            addon_log("Regex: -- No notplayable --")
                        try:
                            regexs[i('name')[0].string]['noredirect'] = i('noredirect')[0].string
                        except:
                            addon_log("Regex: -- No noredirect --")
                        try:
                            regexs[i('name')[0].string]['origin'] = i('origin')[0].string
                        except:
                            addon_log("Regex: -- No origin --")
                        try:
                            regexs[i('name')[0].string]['accept'] = i('accept')[0].string
                        except:
                            addon_log("Regex: -- No accept --")
                        try:
                            regexs[i('name')[0].string]['includeheaders'] = i('includeheaders')[0].string
                        except:
                            addon_log("Regex: -- No includeheaders --")
                        try:
                            regexs[i('name')[0].string]['listrepeat'] = i('listrepeat')[0].string
                            #print 'listrepeat',regexs[i('name')[0].string]['listrepeat'],i('listrepeat')[0].string, i
                        except:
                            addon_log("Regex: -- No listrepeat --")
                        try:
                            regexs[i('name')[0].string]['proxy'] = i('proxy')[0].string
                        except:
                            addon_log("Regex: -- No proxy --")
                        try:
                            regexs[i('name')[0].string]['x-req'] = i('x-req')[0].string
                        except:
                            addon_log("Regex: -- No x-req --")
                        try:
                            regexs[i('name')[0].string]['x-addr'] = i('x-addr')[0].string
                        except:
                            addon_log("Regex: -- No x-addr --")
                        try:
                            regexs[i('name')[0].string]['x-forward'] = i('x-forward')[0].string
                        except:
                            addon_log("Regex: -- No x-forward --")
                        try:
                            regexs[i('name')[0].string]['agent'] = i('agent')[0].string
                        except:
                            addon_log("Regex: -- No User Agent --")
                        try:
                            regexs[i('name')[0].string]['post'] = i('post')[0].string
                        except:
                            addon_log("Regex: -- Not a post")
                        try:
                            regexs[i('name')[0].string]['rawpost'] = i('rawpost')[0].string
                        except:
                            addon_log("Regex: -- Not a rawpost")
                        try:
                            regexs[i('name')[0].string]['htmlunescape'] = i('htmlunescape')[0].string
                        except:
                            addon_log("Regex: -- Not a htmlunescape")
                        try:
                            regexs[i('name')[0].string]['readcookieonly'] = i('readcookieonly')[0].string
                        except:
                            addon_log("Regex: -- Not a readCookieOnly")
                        #print i
                        try:
                            regexs[i('name')[0].string]['cookiejar'] = i('cookiejar')[0].string
                            if not regexs[i('name')[0].string]['cookiejar']:
                                regexs[i('name')[0].string]['cookiejar']=''
                        except:
                            addon_log("Regex: -- Not a cookieJar")
                        try:
                            regexs[i('name')[0].string]['setcookie'] = i('setcookie')[0].string
                        except:
                            addon_log("Regex: -- Not a setcookie")
                        try:
                            regexs[i('name')[0].string]['appendcookie'] = i('appendcookie')[0].string
                        except:
                            addon_log("Regex: -- Not a appendcookie")
                        try:
                            regexs[i('name')[0].string]['ignorecache'] = i('ignorecache')[0].string
                        except:
                            addon_log("Regex: -- no ignorecache")
                        #try:
                        #    regexs[i('name')[0].string]['ignorecache'] = i('ignorecache')[0].string
                        #except:
                        #    addon_log("Regex: -- no ignorecache")
                    regexs = urllib.quote(repr(regexs))
                    return regexs
                    #print regexs
                except:
                    regexs = None
                    addon_log('regex Error: '+name.encode('utf-8', 'ignore'))

def get_ustream(url):
    try:
        for i in range(1, 51):
            result = getUrl(url)
            if "EXT-X-STREAM-INF" in result: return url
            if not "EXTM3U" in result: return
            xbmc.sleep(2000)
        return
    except:
        return

def getRegexParsed(regexs, url,cookieJar=None,forCookieJarOnly=False,recursiveCall=False,cachedPages={}, rawPost=False, cookie_jar_file=None):#0,1,2 = URL, regexOnly, CookieJarOnly
        if not recursiveCall:
            regexs = eval(urllib.unquote(regexs))
        #cachedPages = {}
        #print 'url',url
        doRegexs = re.compile('\$doregex\[([^\]]*)\]').findall(url)
        #print 'doRegexs',doRegexs,regexs
        setresolved=True
        for k in doRegexs:
            if k in regexs:
                #print 'processing ' ,k
                m = regexs[k]
                #print m
                cookieJarParam=False
                if  'cookiejar' in m: # so either create or reuse existing jar
                    #print 'cookiejar exists',m['cookiejar']
                    cookieJarParam=m['cookiejar']
                    if  '$doregex' in cookieJarParam:
                        cookieJar=getRegexParsed(regexs, m['cookiejar'],cookieJar,True, True,cachedPages)
                        cookieJarParam=True
                    else:
                        cookieJarParam=True
                #print 'm[cookiejar]',m['cookiejar'],cookieJar
                if cookieJarParam:
                    if cookieJar==None:
                        #print 'create cookie jar'
                        cookie_jar_file=None
                        if 'open[' in m['cookiejar']:
                            cookie_jar_file=m['cookiejar'].split('open[')[1].split(']')[0]
                            #print 'cookieJar from file name',cookie_jar_file
                        cookieJar=getCookieJar(cookie_jar_file)
                        #print 'cookieJar from file',cookieJar
                        if cookie_jar_file:
                            saveCookieJar(cookieJar,cookie_jar_file)
                        #import cookielib
                        #cookieJar = cookielib.LWPCookieJar()
                        #print 'cookieJar new',cookieJar
                    elif 'save[' in m['cookiejar']:
                        cookie_jar_file=m['cookiejar'].split('save[')[1].split(']')[0]
                        complete_path=os.path.join(profile,cookie_jar_file)
                        #print 'complete_path',complete_path
                        saveCookieJar(cookieJar,cookie_jar_file)
                if  m['page'] and '$doregex' in m['page']:
                    m['page']=getRegexParsed(regexs, m['page'],cookieJar,recursiveCall=True,cachedPages=cachedPages)
                if 'referer' in m and m['referer'] and '$doregex' in m['referer']:
                    m['referer']=getRegexParsed(regexs, m['referer'],cookieJar,recursiveCall=True,cachedPages=cachedPages)
                if 'setcookie' in m and m['setcookie'] and '$doregex' in m['setcookie']:
                    m['setcookie']=getRegexParsed(regexs, m['setcookie'],cookieJar,recursiveCall=True,cachedPages=cachedPages)
                if 'appendcookie' in m and m['appendcookie'] and '$doregex' in m['appendcookie']:
                    m['appendcookie']=getRegexParsed(regexs, m['appendcookie'],cookieJar,recursiveCall=True,cachedPages=cachedPages)
                if  'post' in m and '$doregex' in m['post']:
                    m['post']=getRegexParsed(regexs, m['post'],cookieJar,recursiveCall=True,cachedPages=cachedPages)
                    #print 'post is now',m['post']
                if  'rawpost' in m and '$doregex' in m['rawpost']:
                    m['rawpost']=getRegexParsed(regexs, m['rawpost'],cookieJar,recursiveCall=True,cachedPages=cachedPages,rawPost=True)
                    #print 'rawpost is now',m['rawpost']
                if 'rawpost' in m and '$epoctime$' in m['rawpost']:
                    m['rawpost']=m['rawpost'].replace('$epoctime$',getEpocTime())
                if 'rawpost' in m and '$epoctime2$' in m['rawpost']:
                    m['rawpost']=m['rawpost'].replace('$epoctime2$',getEpocTime2())
                link=''
                if m['page'] and m['page'] in cachedPages and not 'ignorecache' in m and forCookieJarOnly==False :
                    link = cachedPages[m['page']]
                else:
                    if m['page'] and  not m['page']=='' and  m['page'].startswith('http'):
                        if '$epoctime$' in m['page']:
                            m['page']=m['page'].replace('$epoctime$',getEpocTime())
                        if '$epoctime2$' in m['page']:
                            m['page']=m['page'].replace('$epoctime2$',getEpocTime2())
                        #print 'Ingoring Cache',m['page']
                        page_split=m['page'].split('|')
                        pageUrl=page_split[0]
                        header_in_page=None
                        if len(page_split)>1:
                            header_in_page=page_split[1]
#                            if
#                            proxy = urllib2.ProxyHandler({ ('https' ? proxytouse[:5]=="https":"http") : proxytouse})
#                            opener = urllib2.build_opener(proxy)
#                            urllib2.install_opener(opener)
#                        import urllib2
#                        print 'urllib2.getproxies',urllib2.getproxies()
                        current_proxies=urllib2.ProxyHandler(urllib2.getproxies())
                        req = urllib2.Request(pageUrl)
                        if 'proxy' in m:
                            proxytouse= m['proxy']
                            #print 'proxytouse',proxytouse
                            #urllib2.getproxies= lambda: {}
                            if pageUrl[:5]=="https":
                                proxy = urllib2.ProxyHandler({ 'https' : proxytouse})
                                #req.set_proxy(proxytouse, 'https')
                            else:
                                proxy = urllib2.ProxyHandler({ 'http'  : proxytouse})
                                #req.set_proxy(proxytouse, 'http')
                            opener = urllib2.build_opener(proxy)
                            urllib2.install_opener(opener)
                        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36')
                        proxytouse=None
                        if 'referer' in m:
                            req.add_header('Referer', m['referer'])
                        if 'accept' in m:
                            req.add_header('Accept', m['accept'])
                        if 'agent' in m:
                            req.add_header('User-agent', m['agent'])
                        if 'x-req' in m:
                            req.add_header('X-Requested-With', m['x-req'])
                        if 'x-addr' in m:
                            req.add_header('x-addr', m['x-addr'])
                        if 'x-forward' in m:
                            req.add_header('X-Forwarded-For', m['x-forward'])
                        if 'setcookie' in m:
                            #print 'adding cookie',m['setcookie']
                            req.add_header('Cookie', m['setcookie'])
                        if 'appendcookie' in m:
                            #print 'appending cookie to cookiejar',m['appendcookie']
                            cookiestoApend=m['appendcookie']
                            cookiestoApend=cookiestoApend.split(';')
                            for h in cookiestoApend:
                                n,v=h.split('=')
                                w,n= n.split(':')
                                ck = cookielib.Cookie(version=0, name=n, value=v, port=None, port_specified=False, domain=w, domain_specified=False, domain_initial_dot=False, path='/', path_specified=True, secure=False, expires=None, discard=True, comment=None, comment_url=None, rest={'HttpOnly': None}, rfc2109=False)
                                cookieJar.set_cookie(ck)
                        if 'origin' in m:
                            req.add_header('Origin', m['origin'])
                        if header_in_page:
                            header_in_page=header_in_page.split('&')
                            for h in header_in_page:
                                n,v=h.split('=')
                                req.add_header(n,v)
                        if not cookieJar==None:
#                            print 'cookieJarVal',cookieJar
                            cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
                            opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
                            opener = urllib2.install_opener(opener)
#                            print 'noredirect','noredirect' in m
                            if 'noredirect' in m:
                                opener = urllib2.build_opener(cookie_handler,NoRedirection, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
                                opener = urllib2.install_opener(opener)
                        elif 'noredirect' in m:
                            opener = urllib2.build_opener(NoRedirection, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
                            opener = urllib2.install_opener(opener)
                        if 'connection' in m:
#                            print '..........................connection//////.',m['connection']
                            from keepalive import HTTPHandler
                            keepalive_handler = HTTPHandler()
                            opener = urllib2.build_opener(keepalive_handler)
                            urllib2.install_opener(opener)
                        #print 'after cookie jar'
                        post=None
                        if 'post' in m:
                            postData=m['post']
                            #if '$LiveStreamRecaptcha' in postData:
                            #    (captcha_challenge,catpcha_word,idfield)=processRecaptcha(m['page'],cookieJar)
                            #    if captcha_challenge:
                            #        postData=postData.replace('$LiveStreamRecaptcha','manual_recaptcha_challenge_field:'+captcha_challenge+',recaptcha_response_field:'+catpcha_word+',id:'+idfield)
                            splitpost=postData.split(',');
                            post={}
                            for p in splitpost:
                                n=p.split(':')[0];
                                v=p.split(':')[1];
                                post[n]=v
                            post = urllib.urlencode(post)
                        if 'rawpost' in m:
                            post=m['rawpost']
                            #if '$LiveStreamRecaptcha' in post:
                            #    (captcha_challenge,catpcha_word,idfield)=processRecaptcha(m['page'],cookieJar)
                            #    if captcha_challenge:
                            #       post=post.replace('$LiveStreamRecaptcha','&manual_recaptcha_challenge_field='+captcha_challenge+'&recaptcha_response_field='+catpcha_word+'&id='+idfield)
                        link=''
                        try:
                            if post:
                                response = urllib2.urlopen(req,post)
                            else:
                                response = urllib2.urlopen(req)
                            link = response.read()
                            if 'proxy' in m and not current_proxies is None:
                                urllib2.install_opener(urllib2.build_opener(current_proxies))
                            link=javascriptUnEscape(link)
                            #print repr(link)
                            #print link This just print whole webpage in LOG
                            if 'includeheaders' in m:
                                #link+=str(response.headers.get('Set-Cookie'))
                                link+='$$HEADERS_START$$:'
                                for b in response.headers:
                                    link+= b+':'+response.headers.get(b)+'\n'
                                link+='$$HEADERS_END$$:'
    #                        print link
                            addon_log(link)
                            addon_log(cookieJar )
                            response.close()
                        except: pass
                        cachedPages[m['page']] = link
                        #print link
                        #print 'store link for',m['page'],forCookieJarOnly
                        if forCookieJarOnly:
                            return cookieJar# do nothing
                    elif m['page'] and  not m['page'].startswith('http'):
                        if m['page'].startswith('$pyFunction:'):
                            val=doEval(m['page'].split('$pyFunction:')[1],'',cookieJar,m )
                            if forCookieJarOnly:
                                return cookieJar# do nothing
                            link=val
                            link=javascriptUnEscape(link)
                        else:
                            link=m['page']
                if '$pyFunction:playmedia(' in m['expres'] or 'ActivateWindow'  in m['expres']  or '$PLAYERPROXY$=' in url  or  any(x in url for x in g_ignoreSetResolved):
                    setresolved=False
                if  '$doregex' in m['expres']:
                    m['expres']=getRegexParsed(regexs, m['expres'],cookieJar,recursiveCall=True,cachedPages=cachedPages)
                if not m['expres']=='':
                    #print 'doing it ',m['expres']
                    if '$LiveStreamCaptcha' in m['expres']:
                        val=askCaptcha(m,link,cookieJar)
                        #print 'url and val',url,val
                        url = url.replace("$doregex[" + k + "]", val)
                    elif m['expres'].startswith('$pyFunction:') or '#$pyFunction' in m['expres']:
                        #print 'expeeeeeeeeeeeeeeeeeee',m['expres']
                        if m['expres'].startswith('$pyFunction:'):
                            val=doEval(m['expres'].split('$pyFunction:')[1],link,cookieJar,m)
                        else:
                            val=doEvalFunction(m['expres'],link,cookieJar,m)
                        if 'ActivateWindow' in m['expres']: return
#                        print 'url k val',url,k,val
                        #print 'repr',repr(val)
                        try:
                            url = url.replace(u"$doregex[" + k + "]", val)
                        except: url = url.replace("$doregex[" + k + "]", val.decode("utf-8"))
                    else:
                        if 'listrepeat' in m:
                            listrepeat=m['listrepeat']
                            ret=re.findall(m['expres'],link)
                            return listrepeat,ret, m,regexs
                        if not link=='':
                            #print 'link',link
                            reg = re.compile(m['expres']).search(link)
                            val=''
                            try:
                                val=reg.group(1).strip()
                            except: traceback.print_exc()
                        else:
                            val=m['expres']
                        if rawPost:
#                            print 'rawpost'
                            val=urllib.quote_plus(val)
                        if 'htmlunescape' in m:
                            #val=urllib.unquote_plus(val)
                            import HTMLParser
                            val=HTMLParser.HTMLParser().unescape(val)
                        try:
                            url = url.replace("$doregex[" + k + "]", val)
                        except: url = url.replace("$doregex[" + k + "]", val.decode("utf-8"))
                        #return val
                else:
                    url = url.replace("$doregex[" + k + "]",'')
        if '$epoctime$' in url:
            url=url.replace('$epoctime$',getEpocTime())
        if '$epoctime2$' in url:
            url=url.replace('$epoctime2$',getEpocTime2())
        if '$GUID$' in url:
            import uuid
            url=url.replace('$GUID$',str(uuid.uuid1()).upper())
        if '$get_cookies$' in url:
            url=url.replace('$get_cookies$',getCookiesString(cookieJar))
        if recursiveCall: return url
        #print 'final url',repr(url)
        if url=="":
            return
        else:
            return url,setresolved

def playmedia(media_url):
    try:
        import  CustomPlayer
        player = CustomPlayer.MyXBMCPlayer()
        listitem = xbmcgui.ListItem( label = str(name), iconImage = "DefaultVideo.png", thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ), path=media_url )
        player.play( media_url,listitem)
        xbmc.sleep(1000)
        while player.is_active:
            xbmc.sleep(200)
    except:
        traceback.print_exc()
    return ''

def kodiJsonRequest(params):
    data = json.dumps(params)
    request = xbmc.executeJSONRPC(data)
    try:
        response = json.loads(request)
    except UnicodeDecodeError:
        response = json.loads(request.decode('utf-8', 'ignore'))
    try:
        if 'result' in response:
            return response['result']
        return None
    except KeyError:
        logger.warn("[%s] %s" % (params['method'], response['error']['message']))
        return None

def setKodiProxy(proxysettings=None):
    if proxysettings==None:
#        print 'proxy set to nothing'
        xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.usehttpproxy", "value":false}, "id":1}')
    else:
        ps=proxysettings.split(':')
        proxyURL=ps[0]
        proxyPort=ps[1]
        proxyType=ps[2]
        proxyUsername=None
        proxyPassword=None
        if len(ps)>3 and '@' in proxysettings:
            proxyUsername=ps[3]
            proxyPassword=proxysettings.split('@')[-1]
#        print 'proxy set to', proxyType, proxyURL,proxyPort
        xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.usehttpproxy", "value":true}, "id":1}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxytype", "value":' + str(proxyType) +'}, "id":1}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxyserver", "value":"' + str(proxyURL) +'"}, "id":1}')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxyport", "value":' + str(proxyPort) +'}, "id":1}')
        if not proxyUsername==None:
            xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxyusername", "value":"' + str(proxyUsername) +'"}, "id":1}')
            xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxypassword", "value":"' + str(proxyPassword) +'"}, "id":1}')

def getConfiguredProxy():
    proxyActive = kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.usehttpproxy"}, 'id': 1})['value']
#    print 'proxyActive',proxyActive
    proxyType = kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxytype"}, 'id': 1})['value']
    if proxyActive: # PROXY_HTTP
        proxyURL = kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxyserver"}, 'id': 1})['value']
        proxyPort = unicode(kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxyport"}, 'id': 1})['value'])
        proxyUsername = kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxyusername"}, 'id': 1})['value']
        proxyPassword = kodiJsonRequest({'jsonrpc': '2.0', "method":"Settings.GetSettingValue", "params":{"setting":"network.httpproxypassword"}, 'id': 1})['value']

        if proxyUsername and proxyPassword and proxyURL and proxyPort:
            return proxyURL + ':' + str(proxyPort)+':'+str(proxyType) + ':' + proxyUsername + '@' + proxyPassword
        elif proxyURL and proxyPort:
            return proxyURL + ':' + str(proxyPort)+':'+str(proxyType)
    else:
        return None

def playmediawithproxy(media_url, name, iconImage,proxyip,port):
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Playing with custom proxy')
    progress.update( 10, "", "setting proxy..", "" )
    proxyset=False
    existing_proxy=''
    try:
        existing_proxy=getConfiguredProxy()
#        print 'existing_proxy',existing_proxy
        #read and set here
        setKodiProxy( proxyip + ':' + port+':0')
#        print 'proxy setting complete', getConfiguredProxy()
        proxyset=True
        progress.update( 80, "", "setting proxy complete, now playing", "" )
        progress.close()
        progress=None
        import  CustomPlayer
        player = CustomPlayer.MyXBMCPlayer()
        listitem = xbmcgui.ListItem( label = str(name), iconImage = iconImage, thumbnailImage = xbmc.getInfoImage( "ListItem.Thumb" ), path=media_url )
        player.play( media_url,listitem)
        xbmc.sleep(1000)
        while player.is_active:
            xbmc.sleep(200)
    except:
        traceback.print_exc()
    if progress:
        progress.close()
    if proxyset:
#        print 'now resetting the proxy back'
        setKodiProxy(existing_proxy)
#        print 'reset here'
    return ''

def get_saw_rtmp(page_value, referer=None):
    if referer:
        referer=[('Referer',referer)]
    if page_value.startswith("http"):
        page_url=page_value
        page_value= getUrl(page_value,headers=referer)
    str_pattern="(eval\(function\(p,a,c,k,e,(?:r|d).*)"
    reg_res=re.compile(str_pattern).findall(page_value)
    r=""
    if reg_res and len(reg_res)>0:
        for v in reg_res:
            r1=get_unpacked(v)
            r2=re_me(r1,'\'(.*?)\'')
            if 'unescape' in r1:
                r1=urllib.unquote(r2)
            r+=r1+'\n'
#        print 'final value is ',r
        page_url=re_me(r,'src="(.*?)"')
        page_value= getUrl(page_url,headers=referer)
    #print page_value
    rtmp=re_me(page_value,'streamer\'.*?\'(.*?)\'\)')
    playpath=re_me(page_value,'file\',\s\'(.*?)\'')
    return rtmp+' playpath='+playpath +' pageUrl='+page_url


def re_me(data, re_patten):
    match = ''
    m = re.search(re_patten, data)
    if m != None:
        match = m.group(1)
    else:
        match = ''
    return match

def get_unpacked( page_value, regex_for_text='', iterations=1, total_iteration=1):
    try:
        reg_data=None
        if page_value.startswith("http"):
            page_value= getUrl(page_value)
#        print 'page_value',page_value
        if regex_for_text and len(regex_for_text)>0:
            try:
                page_value=re.compile(regex_for_text).findall(page_value)[0] #get the js variable
            except: return 'NOTPACKED'
        page_value=unpack(page_value,iterations,total_iteration)
    except:
        page_value='UNPACKEDFAILED'
        traceback.print_exc(file=sys.stdout)
#    print 'unpacked',page_value
    if 'sav1live.tv' in page_value:
        page_value=page_value.replace('sav1live.tv','sawlive.tv') #quick fix some bug somewhere
#        print 'sav1 unpacked',page_value
    return page_value

def unpack(sJavascript,iteration=1, totaliterations=2  ):
#    print 'iteration',iteration
    if sJavascript.startswith('var _0xcb8a='):
        aSplit=sJavascript.split('var _0xcb8a=')
        ss="myarray="+aSplit[1].split("eval(")[0]
        exec(ss)
        a1=62
        c1=int(aSplit[1].split(",62,")[1].split(',')[0])
        p1=myarray[0]
        k1=myarray[3]
        with open('temp file'+str(iteration)+'.js', "wb") as filewriter:
            filewriter.write(str(k1))
        #aa=1/0
    else:
        if "rn p}('" in sJavascript:
            aSplit = sJavascript.split("rn p}('")
        else:
            aSplit = sJavascript.split("rn A}('")
#        print aSplit
        p1,a1,c1,k1=('','0','0','')
        ss="p1,a1,c1,k1=('"+aSplit[1].split(".spli")[0]+')'
        exec(ss)
    k1=k1.split('|')
    aSplit = aSplit[1].split("))'")
#    print ' p array is ',len(aSplit)
#   print len(aSplit )
    #p=str(aSplit[0]+'))')#.replace("\\","")#.replace('\\\\','\\')
    #print aSplit[1]
    #aSplit = aSplit[1].split(",")
    #print aSplit[0]
    #a = int(aSplit[1])
    #c = int(aSplit[2])
    #k = aSplit[3].split(".")[0].replace("'", '').split('|')
    #a=int(a)
    #c=int(c)
    #p=p.replace('\\', '')
#    print 'p val is ',p[0:100],'............',p[-100:],len(p)
#    print 'p1 val is ',p1[0:100],'............',p1[-100:],len(p1)
    #print a,a1
    #print c,a1
    #print 'k val is ',k[-10:],len(k)
#    print 'k1 val is ',k1[-10:],len(k1)
    e = ''
    d = ''#32823
    #sUnpacked = str(__unpack(p, a, c, k, e, d))
    sUnpacked1 = str(__unpack(p1, a1, c1, k1, e, d,iteration))
    #print sUnpacked[:200]+'....'+sUnpacked[-100:], len(sUnpacked)
#    print sUnpacked1[:200]+'....'+sUnpacked1[-100:], len(sUnpacked1)
    #exec('sUnpacked1="'+sUnpacked1+'"')
    if iteration>=totaliterations:
#        print 'final res',sUnpacked1[:200]+'....'+sUnpacked1[-100:], len(sUnpacked1)
        return sUnpacked1#.replace('\\\\', '\\')
    else:
#        print 'final res for this iteration is',iteration
        return unpack(sUnpacked1,iteration+1)#.replace('\\', ''),iteration)#.replace('\\', '');#unpack(sUnpacked.replace('\\', ''))

def __unpack(p, a, c, k, e, d, iteration,v=1):
    #with open('before file'+str(iteration)+'.js', "wb") as filewriter:
    #    filewriter.write(str(p))
    while (c >= 1):
        c = c -1
        if (k[c]):
            aa=str(__itoaNew(c, a))
            if v==1:
                p=re.sub('\\b' + aa +'\\b', k[c], p)# THIS IS Bloody slow!
            else:
                p=findAndReplaceWord(p,aa,k[c])
            #p=findAndReplaceWord(p,aa,k[c])
    #with open('after file'+str(iteration)+'.js', "wb") as filewriter:
    #    filewriter.write(str(p))
    return p
#
#function equalavent to re.sub('\\b' + aa +'\\b', k[c], p)

def findAndReplaceWord(source_str, word_to_find,replace_with):
    splits=None
    splits=source_str.split(word_to_find)
    if len(splits)>1:
        new_string=[]
        current_index=0
        for current_split in splits:
            #print 'here',i
            new_string.append(current_split)
            val=word_to_find#by default assume it was wrong to split
            #if its first one and item is blank then check next item is valid or not
            if current_index==len(splits)-1:
                val='' # last one nothing to append normally
            else:
                if len(current_split)==0: #if blank check next one with current split value
                    if ( len(splits[current_index+1])==0 and word_to_find[0].lower() not in 'abcdefghijklmnopqrstuvwxyz1234567890_') or (len(splits[current_index+1])>0  and splits[current_index+1][0].lower() not in 'abcdefghijklmnopqrstuvwxyz1234567890_'):# first just just check next
                        val=replace_with
                #not blank, then check current endvalue and next first value
                else:
                    if (splits[current_index][-1].lower() not in 'abcdefghijklmnopqrstuvwxyz1234567890_') and (( len(splits[current_index+1])==0 and word_to_find[0].lower() not in 'abcdefghijklmnopqrstuvwxyz1234567890_') or (len(splits[current_index+1])>0  and splits[current_index+1][0].lower() not in 'abcdefghijklmnopqrstuvwxyz1234567890_')):# first just just check next
                        val=replace_with
            new_string.append(val)
            current_index+=1
        #aaaa=1/0
        source_str=''.join(new_string)
    return source_str

def __itoa(num, radix):
#    print 'num red',num, radix
    result = ""
    if num==0: return '0'
    while num > 0:
        result = "0123456789abcdefghijklmnopqrstuvwxyz"[num % radix] + result
        num /= radix
    return result

def __itoaNew(cc, a):
    aa="" if cc < a else __itoaNew(int(cc / a),a)
    cc = (cc % a)
    bb=chr(cc + 29) if cc> 35 else str(__itoa(cc,36))
    return aa+bb

def getCookiesString(cookieJar):
    try:
        cookieString=""
        for index, cookie in enumerate(cookieJar):
            cookieString+=cookie.name + "=" + cookie.value +";"
    except: pass
    #print 'cookieString',cookieString
    return cookieString

def saveCookieJar(cookieJar,COOKIEFILE):
    try:
        complete_path=os.path.join(profile,COOKIEFILE)
        cookieJar.save(complete_path,ignore_discard=True)
    except: pass

def getCookieJar(COOKIEFILE):
    cookieJar=None
    if COOKIEFILE:
        try:
            complete_path=os.path.join(profile,COOKIEFILE)
            cookieJar = cookielib.LWPCookieJar()
            cookieJar.load(complete_path,ignore_discard=True)
        except:
            cookieJar=None
    if not cookieJar:
        cookieJar = cookielib.LWPCookieJar()
    return cookieJar

def doEval(fun_call,page_data,Cookie_Jar,m):
    ret_val=''
    if functions_dir not in sys.path:
        sys.path.append(functions_dir)
#    print fun_call
    try:
        py_file='import '+fun_call.split('.')[0]
#        print py_file,sys.path
        exec( py_file)
#        print 'done'
    except:
        #print 'error in import'
        traceback.print_exc(file=sys.stdout)
#    print 'ret_val='+fun_call
    exec ('ret_val='+fun_call)
#    print ret_val
    #exec('ret_val=1+1')
    try:
        return str(ret_val)
    except: return ret_val

def doEvalFunction(fun_call,page_data,Cookie_Jar,m):
#    print 'doEvalFunction'
    ret_val=''
    if functions_dir not in sys.path:
        sys.path.append(functions_dir)
    f=open(functions_dir+"/LSProdynamicCode.py","w")
    f.write(fun_call);
    f.close()
    import LSProdynamicCode
    ret_val=LSProdynamicCode.GetLSProData(page_data,Cookie_Jar,m)
    try:
        return str(ret_val)
    except: return ret_val

def getUrl(url, cookieJar=None,post=None, timeout=20, headers=None, noredir=False):
    cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
    if noredir:
        opener = urllib2.build_opener(NoRedirection,cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    else:
        opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    #opener = urllib2.install_opener(opener)
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36')
    if headers:
        for h,hv in headers:
            req.add_header(h,hv)
    response = opener.open(req,post,timeout=timeout)
    link=response.read()
    response.close()
    return link;

def get_decode(str,reg=None):
    if reg:
        str=re.findall(reg, str)[0]
    s1 = urllib.unquote(str[0: len(str)-1]);
    t = '';
    for i in range( len(s1)):
        t += chr(ord(s1[i]) - s1[len(s1)-1]);
    t=urllib.unquote(t)
#    print t
    return t

def javascriptUnEscape(str):
    js=re.findall('unescape\(\'(.*?)\'',str)
#    print 'js',js
    if (not js==None) and len(js)>0:
        for j in js:
            #print urllib.unquote(j)
            str=str.replace(j ,urllib.unquote(j))
    return str
iid=0

def TakeInput(name, headname):
    kb = xbmc.Keyboard('default', 'heading', True)
    kb.setDefault(name)
    kb.setHeading(headname)
    kb.setHiddenInput(False)
    return kb.getText()

class InputWindow(xbmcgui.WindowDialog):
    def __init__(self, *args, **kwargs):
        self.cptloc = kwargs.get('captcha')
        self.img = xbmcgui.ControlImage(335,30,624,60,self.cptloc)
        self.addControl(self.img)
        self.kbd = xbmc.Keyboard()

    def get(self):
        self.show()
        time.sleep(2)
        self.kbd.doModal()
        if (self.kbd.isConfirmed()):
            text = self.kbd.getText()
            self.close()
            return text
        self.close()
        return False

def getEpocTime():
    import time
    return str(int(time.time()*1000))

def getEpocTime2():
    import time
    return str(int(time.time()))

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                splitparams={}
                splitparams=pairsofparams[i].split('=')
                if (len(splitparams))==2:
                    param[splitparams[0]]=splitparams[1]
        return param

def urlsolver(url):
    import urlresolver
    host = urlresolver.HostedMediaFile(url)
    if host:
        resolver = urlresolver.resolve(url)
        resolved = resolver
        if isinstance(resolved,list):
            for k in resolved:
                quality = addon.getSetting('quality')
                if k['quality'] == 'HD'  :
                    resolver = k['url']
                    break
                elif k['quality'] == 'SD' :
                    resolver = k['url']
                elif k['quality'] == '1080p' and addon.getSetting('1080pquality') == 'true' :
                    resolver = k['url']
                    break
        else:
            resolver = resolved
    else:
        xbmc.executebuiltin("XBMC.Notification(brstuga,Urlresolver donot support this domain. - ,5000)")
    return resolver

def adult():
    Path = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
    arquivo = os.path.join(Path, "pass.txt")
    exists = os.path.isfile(arquivo)
    keyboard = xbmcaddon.Addon().getSetting("keyboard")
    if exists == False:
        parental_password()
        xbmc.sleep(10)
        p_file = open(arquivo,'r+')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        ps = dialog.numeric(0, 'Insira a senha atual:')
        if ps == p_file_b64_decode:
            pass
        else:
            notify('[B]Senha invalida![/B]')
            exit()
    else:
        p_file = open(arquivo,'r+')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        ps = dialog.numeric(0, 'Insira a senha atual:')
        if ps == p_file_b64_decode:
            pass
        else:
            notify('[B]Senha invalida![/B]')
            exit()

def PrivateSource():
    arquivo = 'c3BlY2lhbDovL2hvbWUvdXNlcmRhdGEvcGxheWVyY29yZWZhY3RvcnkueG1s'
    arquivo = base64.b64decode(arquivo).decode('utf-8')
    arquivo = xbmc.translatePath(os.path.join(arquivo))
    exists = os.path.isfile(arquivo)
    if exists == True:
        exit()

def valide(rcs_url,refer,user=False):
    try:
        import ssl
        if '|' in rcs_url:
            rcs_url = rcs_url.split('|')[0]
        req = urllib2.Request(rcs_url)
        if user:
            req.add_header('User-Agent', user)
        else:
            req.add_header('User-Agent', useragent)
        if refer:
            req.add_header('Referer', refer)
        response = urllib2.urlopen(req, context=ssl._create_unverified_context())
        return True
    except:
        return False

def resolver_rc(url):
    try:
        link = getRequest2(url,'','')
        ur = re.compile('iframe.*?src="(.*?)"').findall(link)[0]
        url = server_rc(ur)
        return url
    except:
        return url
        notify('Houve um problema, por favor reporte!')
        exit()

def server_rc(url):
    try:
        if not '&' in url:
            vid = re.compile('vid=(.+)').findall(url)[0]
        else:
            vid = re.compile('vid=(.+?)&').findall(url)[0]
    except:
        vid = re.compile('vid=(.+)').findall(url)[0]
    server = re.compile('server(.*?).php').findall(url)[0].replace('http2','').replace('http','')
    if re.compile('\D').findall(server):
        char = re.compile('\D+').findall(server)[0]
        try:
            dig = re.compile('\d+').findall(server)[0]
        except:
            dig = 1
        url = 'rc%s%s=%s.mp4'%(char,dig,vid)
        return url
    else:
        if int(server) < 10:
            url = 'rc%s=%s.mp4'%(server,vid)
            #notify(url)
            return url
        else:
            url = 'rc%s=%s.mp4'%(server,vid)
            #notify(url)
            return url

def server_rc_erro(url):
    vid = re.compile('(.*)=').findall(url)[0]
    if 'rcf' in vid:
        vid = vid.replace('rcf','')
        vid = 'Servidor ' + vid.upper()
        return vid
    elif 'rc' in vid and not 'f' in vid:
        vid = vid.replace('rc','')
        vid = 'Servidor ' + vid.upper()
        return vid

def rcs_mp4(channel):
    try:
        canal_server = str(re.compile('(.*)=', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0])
        canal = str(re.compile(canal_server+'=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0]).replace('.mp4','')
        canal_link = ''
        canal_link = base64.b64decode(canal_link).decode('utf-8')
        canal_link = getRequest2(canal_link,'',useragent).replace('\n','').replace('\r','')
        canal_link = re.compile(canal_server+'="(.+?)"').findall(canal_link)[0]
        canal_final = canal_link + canal
        #GET URL STREAM
        stream_rc = getRequest2(canal_final,canal_final,useragent).replace('\n','').replace('\r','')
        stream_final = re.compile('source.+?"(.+?)"').findall(stream_rc)[0]
        rcs_resolver = re.compile('baixar.+?"(.+?)"').findall(stream_rc)[0]
        #VALIDAR
        if not stream_final == rcs_resolver:
            if valide(stream_final,canal_final) == False:
                stream_final = rcs_resolver
            if valide(stream_final,canal_final) == False:
                exit()
        else:
            if valide(stream_final,canal_final) == False:
                exit()
        #STREAM PLAY
        url = stream_final + '|Referer=' + canal_final + '&User-Agent=' + urllib.quote_plus(useragent) + '&verifypeer=false'
        return url
    except:
        error = server_rc_erro(channel)
        xbmcgui.Dialog().ok(addon_name, "[B][COLOR orangered]"+error+"[/COLOR] indisponível no momento.[CR][CR]Tente novamente - Se o erro continuar pode ser devido a problema na [COLOR orangered]RedeCanais[/COLOR].[/B]")
        url = ''
        exit()
        return url

def rs_mp4(channel):
    try:
        canal_server = str(re.compile('(.*)=', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0])
        canal = str(re.compile(canal_server+'=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0]).replace('.mp4','')
        canal_link = ''
        canal_link = base64.b64decode(canal_link).decode('utf-8')
        canal_link = getRequest2(canal_link,'',useragent).replace('\n','').replace('\r','')
        canal_link = re.compile(canal_server+'="(.+?)"').findall(canal_link)[0]
        canal_final = canal_link + canal
        #GET URL STREAM
        stream_rc = getRequest2(canal_final,canal_final,useragent).replace('\n','').replace('\r','')
        stream_final = re.compile('source.+?"(.+?)"').findall(stream_rc)[0]
        rcs_resolver = re.compile('baixar.+?"(.+?)"').findall(stream_rc)[0]
        #VALIDAR
        if not stream_final == rcs_resolver:
            if valide(stream_final,canal_final) == False:
                stream_final = rcs_resolver
            if valide(stream_final,canal_final) == False:
                exit()
        else:
            if valide(stream_final,canal_final) == False:
                exit()
        #STREAM PLAY
        url = stream_final + '|Referer=' + canal_final + '&User-Agent=' + urllib.quote_plus(useragent)
        return url
    except:
        xbmcgui.Dialog().ok(addon_name, "[B][COLOR orangered]Vídeo[/COLOR] indisponível no momento.[CR][CR]Tente novamente - Se o erro continuar pode ser devido a problema na [COLOR orangered]RediSex[/COLOR].[/B]")
        url = ''
        exit()
        return url

def CanaisMix(channel):
    try:
        import jsunpack
        canal = str(re.compile('canaismix=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0]).replace('.m3u8','')
        canal_link = ''
        canal_link = base64.b64decode(canal_link).decode('utf-8')
        canal_link = getRequest2(canal_link,'','')
        canal_link = re.compile('canaismix="(.+?)"').findall(canal_link)[0]
        canal_link = base64.b16decode(canal_link[::-1]).decode('utf-8')
        canal_final = canal_link + canal
        stream = getRequest2(canal_final,'','')
        texto = re.findall('(eval\(.+?)</script>', stream, re.MULTILINE|re.DOTALL|re.IGNORECASE)[0]
        unpack = jsunpack.unpack(texto)
        unpack = re.findall('src:(.+?).type', unpack, re.MULTILINE|re.DOTALL|re.IGNORECASE)[0]
        filtro = re.compile('String.fromCharCode\((.+?)\)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(unpack)
        for delete in filtro:
            novo = chr(int(delete) & 0xffff)
            unpack = unpack.replace('String.fromCharCode('+delete+')',"'"+novo+"'")
        filtro = re.compile("(\\\\u0.+?)'", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(unpack)
        for delete in filtro:
            novo = delete.decode('unicode_escape')
            unpack = unpack.replace(delete,novo)
        unpack = 'https:' + unpack.replace("+",'').replace("'",'')
        url = unpack + '|Referer='+canal_final+'&User-Agent='+urllib.quote_plus(useragent)
        if int(player_f4m) == 0:
            url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        return url
    except:
        xbmcgui.Dialog().ok(addon_name, "[B][COLOR orangered]Canal[/COLOR] indisponível no momento.[/B]")
        #notify('[B]Falha ao resolver ou indisponível no momento.[/B]')
        url = ''
        exit()
        return url

def netcine_resolver(channel):
    try:
        link = getRequest2(channel,'','')
        Dual_Lang = re.compile('<iframe.+?src="(.+?)".+?</iframe>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link)
        Dual_Select = []
        Dual_Name = []
        for idioma in Dual_Lang:
            if not '/players/' in idioma:
                idioma = idioma.replace('p.netcine.biz/','p.netcine.biz/players/')
                dados = getRequest2(idioma,'','')
                if not 'location.href=' in dados:
                    dados = re.compile('<iframe.+?src="(.+?)".+?</iframe>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(dados)[0]
                    dados = getRequest2(dados,'','')
                    dados = re.compile('data=(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(dados)[0]
                    dados = getRequest2(dados,'','')
                    #DUB OR LEG
                    video = re.compile("file':'(.+?)'", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(dados)
                    for quality in video:
                        if '-ALTO' in quality:
                            if re.search("DUB",quality,re.IGNORECASE):
                                Dual_Name.append('[B]ASSISTIR DUBLADO[/B]')
                                Dual_Select.append(quality)
                            elif re.search("LEG",quality,re.IGNORECASE):
                                Dual_Name.append('[B]ASSISTIR LEGENDADO[/B]')
                                Dual_Select.append(quality)
                            else:
                                Dual_Select.append(quality)
                else:
                    dados = re.compile("location.href='(.+?)'", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(dados)
                    for url in dados:
                        if 'desktop' in url:
                            dados = getRequest2(url,'','')
                            video = re.compile("file':'(.+?)'", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(dados)
                            for quality in video:
                                if '-ALTO' in quality:
                                    if re.search("DUB",quality,re.IGNORECASE):
                                        Dual_Name.append('[B]ASSISTIR [COLOR orangered]DUBLADO[/COLOR][/B]')
                                        Dual_Select.append(quality)
                                    elif re.search("LEG",quality,re.IGNORECASE):
                                        Dual_Name.append('[B]ASSISTIR [COLOR orangered]LEGENDADO[/COLOR][/B]')
                                        Dual_Select.append(quality)
                                    else:
                                        Dual_Select.append(quality)
        if len(Dual_Select) > 1:
            if 'ASSISTIR LEGENDADO' in Dual_Name[0]:
                Dual_Name.reverse()
                Dual_Select.reverse()
            dialog = xbmcgui.Dialog()
            index = dialog.select('ESCOLHA O IDIOMA', Dual_Name)
            if index >= 0:
                return Dual_Select[index] + '|Referer=https://p.netcine.biz/'
            else:
                return ''
        else:
            return Dual_Select[0] + '|Referer=https://p.netcine.biz/'
    except:
        xbmcgui.Dialog().ok(addon_name, "[B][COLOR orangered]Filme/Série[/COLOR] indisponível no momento.[CR][CR]Tente novamente - Se o erro continuar pode ser devido a problema na [COLOR orangered]NetCine[/COLOR].[/B]")
        #notify('[B]Falha ao resolver ou indisponível no momento.[/B]')
        url = ''
        return url

def hub_resolver(channel):
    try:
        mobile = 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36'
        link = getRequest2(channel,'',mobile).replace('\n','').replace('\r','')
        video = re.compile('videoUrl.+?"(.+?)"').findall(link)
        for play in video:
            if '.mp4.urlset' in play and '.m3u8' in play:
                player = play
                break
        player = player.replace('\/','/')
        url = player + '|User-Agent=' + urllib.quote_plus(mobile)
        return url
    except:
        xbmcgui.Dialog().ok(addon_name, "[B]Falha ao resolver ou indisponível no momento.[/B]")
        #notify('[B]Falha ao resolver ou indisponível no momento.[/B]')
        url = ''
        exit()
        return url

def twth1_m3u8(channel):
    try:
        canal = str(re.compile('rc1_m3u8=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0]).replace('.m3u8','')
        canal_link = ''
        canal_link = base64.b64decode(canal_link).decode('utf-8')
        canal_link = getRequest2(canal_link,'',useragent).replace('\n','').replace('\r','')
        canal_link = re.compile('rch1="(.+?)"').findall(canal_link)
        canal_final = canal_link[0] + canal
        #GET URL STREAM
        stream_rc = getRequest2(canal_final,canal_final,useragent).replace('\n','').replace('\r','')
        stream_final = re.compile('source.+?"(.+?)"').findall(stream_rc)[0]
        #VALIDAR
        if valide(stream_final,canal_final) == False:
            exit()
        #STREAM PLAY
        url = stream_final + '|Referer=' + canal_final + '&User-Agent=' + urllib.quote_plus(useragent)
        if int(player_f4m) == 0:
            url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        return url
    except:
        xbmcgui.Dialog().ok(addon_name, "[B][COLOR orangered]Canal[/COLOR] indisponível no momento.[CR][CR]Tente novamente - Se o erro continuar pode ser devido a problema na [COLOR orangered]RedeCanaisTV[/COLOR].[/B]")
        url = ''
        exit()
        return url

def server_twt2(channel):
    PrivateSource()
    try:
        canal_server = str(re.compile('(.*)=', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0])
        canal = str(re.compile(canal_server+'=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0]).replace('.m3u8','').replace('.ts','')
        canal_link = ''
        canal_link = base64.b64decode(canal_link).decode('utf-8')
        canal_link = getRequest2(canal_link,'','')
        canal_link = re.compile(canal_server+'="(.+?)"').findall(canal_link)[0]
        canal_link = base64.b16decode(canal_link[::-1]).decode('utf-8')
        canal_final = canal_link % canal
        #Verify
        if '|User-Agent=' in canal_final:
            try:
                user_verify = canal_final.split('|User-Agent=')[1]
            except:
                user_verify = ''
            try:
                refer_verify = canal_final.split('&Referer=')[1]
            except:
                refer_verify = ''
        elif '|Referer=' in canal_final:
            try:
                user_verify = canal_final.split('&User-Agent=')[1]
            except:
                user_verify = ''
            try:
                refer_verify = canal_final.split('|Referer=')[1]
            except:
                refer_verify = ''
        if valide(canal_final,refer_verify,user_verify) == False:
            exit()
        #STREAM PLAY
        url = canal_final
        if int(player_f4m) == 0 and '.m3u8' in channel:
            url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        elif int(player_f4m) == 0 and '.ts' in channel:
            url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        return url
    except:
        xbmcgui.Dialog().ok(addon_name, "[B]Falha ao resolver ou indisponível no momento.[/B]")
        #notify('[B]Falha ao resolver ou indisponível no momento.[/B]')
        url = ''
        exit()
        return url

def server_twt3(channel):
    PrivateSource()
    try:
        canal = str(re.compile('brtv3=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0]).replace('.m3u8','')
        url = ''
        url = base64.b64decode(url).decode('utf-8')
        user_agent = ''
        user_agent = base64.b64decode(user_agent).decode('utf-8')
        user = ''
        user = base64.b64decode(user).decode('utf-8')
        user_id = ''
        user_id = base64.b64decode(user_id).decode('utf-8')
        url_regex = getRequest2(url,'',user)
        user_agent_regex = getRequest2(user_agent,'',user).replace('\n','').replace('\r','')
        url_regex = url_regex.replace('\/','/')
        stream_play = re.compile('channel_url.+?"(.+?)"').findall(url_regex)[0]
        stream_play = re.compile('(http.+\/)[0-9]').findall(stream_play)[0] + canal
        stream_referer = re.compile('useragent.+?"(.+?)"').findall(user_agent_regex)[0]# + user_id
        url = stream_play + '|User-Agent=' + stream_referer + user_id
        if int(player_f4m) == 0:
            url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        return url
    except:
        xbmcgui.Dialog().ok(addon_name, "[B]Falha ao resolver ou indisponível no momento.[/B]")
        #notify('[B]Falha ao resolver ou indisponível no momento.[/B]')
        url = ''
        exit()
        return url

def server_twt4(channel):
    PrivateSource()
    try:
        canal = str(re.compile('brtv4=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0]).replace('.m3u8','')
        url = ''
        url = base64.b64decode(url).decode('utf-8')
        user_agent = ''
        user_agent = base64.b64decode(user_agent).decode('utf-8')
        user = ''
        user = base64.b64decode(user).decode('utf-8')
        #user_id = ''
        #user_id = base64.b64decode(user_id).decode('utf-8')
        url_regex = getRequest2(url,'',user)
        user_agent_regex = getRequest2(user_agent,'',user).replace('\n','').replace('\r','')
        url_regex = url_regex.replace('\/','/')
        stream_play = re.compile('channel_url.+?"(.+?)"').findall(url_regex)[0]
        stream_play = re.compile('(http.+\/)[0-9]').findall(stream_play)[0] + canal
        stream_referer = re.compile('useragent.+?"(.+?)"').findall(user_agent_regex)[0]# + user_id
        url = stream_play + '|User-Agent=' + stream_referer
        if int(player_f4m) == 0:
            url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        return url
    except:
        xbmcgui.Dialog().ok(addon_name, "[B]Falha ao resolver ou indisponível no momento.[/B]")
        #notify('[B]Falha ao resolver ou indisponível no momento.[/B]')
        url = ''
        exit()
        return url

def server_twt5(channel):
    PrivateSource()
    try:
        canal = str(re.compile('twttv5=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0]).replace('.m3u8','')
        canal_link = ''
        canal_link = base64.b64decode(canal_link).decode('utf-8')
        canal_link = getRequest2(canal_link,'',useragent)
        canal_link = re.compile('playermulti="(.+?)"').findall(canal_link)[0]
        canal_link = base64.b64decode(canal_link).decode('utf-8')
        canal_link = canal_link%(canal)
        referer = ''
        referer = base64.b64decode(referer).decode('utf-8')
        #GET URL STREAM
        url = canal_link + referer + urllib.quote_plus(useragent)
        #exit()
        if int(player_f4m) == 0:
            url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        return url
    except:
        xbmcgui.Dialog().ok(addon_name, "[B]Falha ao resolver ou indisponível no momento.[/B]")
        #notify('[B]Falha ao resolver ou indisponível no momento.[/B]')
        url = ''
        exit()
        return url

def server_twt6(channel):
    PrivateSource()
    try:
        canal = str(re.compile('twttv6=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0]).replace('.m3u8','')
        canal_link = ''
        canal_link = base64.b64decode(canal_link).decode('utf-8')
        canal_link = getRequest2(canal_link,'',useragent).replace('\n','').replace('\r','')
        referer = re.compile('refer="(.+?)"').findall(canal_link)[0]
        referer = base64.b64decode(referer).decode('utf-8')
        canal_link = re.compile('player="(.+?)"').findall(canal_link)[0]
        stream_final = base64.b64decode(canal_link).decode('utf-8')
        #GET URL STREAM
        url = stream_final + canal + '.m3u8' + '|User-Agent=' + referer
        #exit()
        if int(player_f4m) == 0:
            url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        return url
    except:
        xbmcgui.Dialog().ok(addon_name, "[B]Falha ao resolver ou indisponível no momento.[/B]")
        #notify('[B]Falha ao resolver ou indisponível no momento.[/B]')
        url = ''
        exit()
        return url

def server_ch24h(channel):
    PrivateSource()
    try:
        canal = str(re.compile('ch24h=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0]).replace('.m3u8','')
        stream_play = ''
        stream_play = base64.b64decode(stream_play).decode('utf-8')
        url = stream_play + canal
        if int(player_f4m) == 0:
            url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        return url
    except:
        xbmcgui.Dialog().ok(addon_name, "[B]Falha ao resolver ou indisponível no momento.[/B]")
        #notify('[B]Falha ao resolver ou indisponível no momento.[/B]')
        url = ''
        exit()
        return url

def server_test(channel):
    try:
        canal = str(re.compile('booyah=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(channel)[0]).replace('.m3u8','')
        session = ''
        session = base64.b64decode(session).decode('utf-8')
        url = 'https://'%(canal)
        booyah_session = getRequest2(session,'','')
        booyah = re.compile('loading="(.+?)"').findall(booyah_session)[0]
        booyah_session = re.compile('loading_session="(.+?)"').findall(booyah_session)[0]
        request_headers = {
        "Booyah-Session-Key": booyah_session,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0",
        "Referer": "https://booyah.live/"
        }
        request = urllib2.Request(url, headers=request_headers)
        response = urllib2.urlopen(request).read().decode('utf8')
        response = response.replace('\n','').replace('\r','')
        stream_play = re.compile('url_path.+?"(.+?)"').findall(response)[0]
        url = booyah + stream_play
        if int(player_f4m) == 0:
            url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        return url
    except:
        xbmcgui.Dialog().ok(addon_name, "[B]Falha ao resolver ou indisponível no momento.[/B]")
        #notify('[B]Falha ao resolver ou indisponível no momento.[/B]')
        url = ''
        exit()
        return url

def play_playlist(name,description,iconimage,mu_playlist,queueVideo=None):
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        if addon.getSetting('ask_playlist_items') == 'true' and not queueVideo :
            import urlparse
            names = []
            iloop=0
            #print mu_playlist
            for i in mu_playlist:
                #print i
                if '$$lsname=' in i:
                    d_name=i.split('$$lsname=')[1].split('&regexs')[0]
                    d_name = d_name.replace(';','')
                    d_name += ' - OPÇÃO ' + str(iloop+1)
                    names.append(d_name)
                    mu_playlist[iloop]=i.split('$$lsname=')[0]+('&regexs'+i.split('&regexs')[1] if '&regexs' in i else '')
                else:
                    d_name=urlparse.urlparse(i).netloc
                    if d_name == '':
                        names.append(name+' - OPÇÃO ' + str(iloop+1))
                    else:
                        names.append(d_name+' - OPÇÃO ' + str(iloop+1))
                iloop+=1
            dialog = xbmcgui.Dialog()
            index = dialog.select('ESCOLHA UMA OPÇÃO', names)
            if index >= 0:
                playname=names[index]
                #print 'playnamexx',playname
                if canais_adultos == 'true' and re.search("PlayBoy",name,re.IGNORECASE) or re.search("SexyHot",name,re.IGNORECASE) or re.search("SexTreme",name,re.IGNORECASE) or re.search("Venus",name,re.IGNORECASE):
                    adult()
                if "&mode=19" in mu_playlist[index]:
                    #playsetresolved (urlsolver(mu_playlist[index].replace('&mode=19','')),name,iconimage,True)
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':playname,'Plot':description})
                    liz.setProperty("IsPlayable","true")
                    urltoplay=urlsolver(mu_playlist[index].replace('&mode=19','').replace(';',''))
                    liz.setPath(urltoplay)
                    playlist.add(url, liz)
                    if urltoplay.startswith("plugin://plugin.video.f4mTester"):
                        xbmc.executebuiltin('RunPlugin('+urltoplay+')')
                    else:
                        xbmc.Player().play(playlist)
                        xbmc.executebuiltin('PlayerControl(RepeatAll)')
                elif mu_playlist[index].find('rc1_m3u8=') >= 0 or mu_playlist[index].find('rc2_m3u8=') >= 0 and mu_playlist[index].find('m3u8') >= 0:
                    if mu_playlist[index].find('rc1_m3u8=') >= 0:
                        url = rch1_m3u8(mu_playlist[index])
                    elif mu_playlist[index].find('rc2_m3u8=') >= 0:
                        url = rch2_m3u8(mu_playlist[index])
                    url = url.replace(';','')
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':name,'Plot':description})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url)
                    playlist.add(url, liz)
                    if url.startswith("plugin://plugin.video.f4mTester"):
                        xbmc.executebuiltin('RunPlugin('+url+')')
                    else:
                        xbmc.Player().play(playlist)
                        xbmc.executebuiltin('PlayerControl(RepeatAll)')
                elif 'btv1=' in mu_playlist[index] or 'btv2=' in mu_playlist[index] or 'btv3=' in mu_playlist[index] or 'btv4=' in mu_playlist[index] or 'btv5=' in mu_playlist[index] or 'btv6=' in mu_playlist[index] or 'btv7=' in mu_playlist[index] or 'btv8=' in mu_playlist[index] or 'btv9=' in mu_playlist[index] or 'btv10=' in mu_playlist[index]:
                    url = server_twt2(mu_playlist[index])
                    url = url.replace(';','')
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':name,'Plot':description})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url)
                    playlist.add(url, liz)
                    if url.startswith("plugin://plugin.video.f4mTester"):
                        xbmc.executebuiltin('RunPlugin('+url+')')
                    else:
                        xbmc.Player().play(playlist)
                        xbmc.executebuiltin('PlayerControl(RepeatAll)')
                elif 'canaismix=' in mu_playlist[index] and 'm3u8' in mu_playlist[index]:
                    url = CanaisMix(mu_playlist[index])
                    url = url.replace(';','')
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':name,'Plot':description})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url)
                    playlist.add(url, liz)
                    if url.startswith("plugin://plugin.video.f4mTester"):
                        xbmc.executebuiltin('RunPlugin('+url+')')
                    else:
                        xbmc.Player().play(playlist)
                        xbmc.executebuiltin('PlayerControl(RepeatAll)')
                elif mu_playlist[index].find('twttv3=') >= 0 and mu_playlist[index].find('m3u8') >= 0:
                    url = server_twt3(mu_playlist[index])
                    url = url.replace(';','')
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':name,'Plot':description})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url)
                    playlist.add(url, liz)
                    if url.startswith("plugin://plugin.video.f4mTester"):
                        xbmc.executebuiltin('RunPlugin('+url+')')
                    else:
                        xbmc.Player().play(playlist)
                        xbmc.executebuiltin('PlayerControl(RepeatAll)')
                elif mu_playlist[index].find('twttv4=') >= 0 and mu_playlist[index].find('m3u8') >= 0:
                    url = server_twt4(mu_playlist[index])
                    url = url.replace(';','')
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':name,'Plot':description})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url)
                    playlist.add(url, liz)
                    if url.startswith("plugin://plugin.video.f4mTester"):
                        xbmc.executebuiltin('RunPlugin('+url+')')
                    else:
                        xbmc.Player().play(playlist)
                        xbmc.executebuiltin('PlayerControl(RepeatAll)')
                elif mu_playlist[index].find('twttv5=') >= 0 and mu_playlist[index].find('m3u8') >= 0:
                    url = server_twt5(mu_playlist[index])
                    url = url.replace(';','')
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':name,'Plot':description})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url)
                    playlist.add(url, liz)
                    if url.startswith("plugin://plugin.video.f4mTester"):
                        xbmc.executebuiltin('RunPlugin('+url+')')
                    else:
                        xbmc.Player().play(playlist)
                        xbmc.executebuiltin('PlayerControl(RepeatAll)')
                elif mu_playlist[index].find('twttv6=') >= 0 and mu_playlist[index].find('m3u8') >= 0:
                    url = server_twt6(mu_playlist[index])
                    url = url.replace(';','')
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':name,'Plot':description})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url)
                    playlist.add(url, liz)
                    if url.startswith("plugin://plugin.video.f4mTester"):
                        xbmc.executebuiltin('RunPlugin('+url+')')
                    else:
                        xbmc.Player().play(playlist)
                        xbmc.executebuiltin('PlayerControl(RepeatAll)')
                elif "$doregex" in mu_playlist[index]:
                    #print mu_playlist[index]
                    sepate = mu_playlist[index].split('&regexs=')
                    #print sepate
                    url,setresolved = getRegexParsed(sepate[1], sepate[0])
                    url2 = url.replace(';','')
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':playname,'Plot':description})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url2)
                    playlist.add(url, liz)
                    if url2.startswith("plugin://plugin.video.f4mTester"):
                        xbmc.executebuiltin('RunPlugin('+url2+')')
                    else:
                        xbmc.Player().play(playlist)
                        xbmc.executebuiltin('PlayerControl(RepeatAll)')
                elif 'https://' in mu_playlist[index] or 'http://' in mu_playlist[index] and '.m3u8' in mu_playlist[index] and int(player_f4m) == 0:
                    url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+urllib.quote_plus(str(playname))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(mu_playlist[index])+'&description='+urllib.quote_plus(description)
                    xbmc.executebuiltin('RunPlugin('+url+')')
                elif 'https://' in mu_playlist[index] or 'http://' in mu_playlist[index] and '.ts' in mu_playlist[index] and int(player_f4m) == 0:
                    url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name='+urllib.quote_plus(str(playname))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(mu_playlist[index])+'&description='+urllib.quote_plus(description)
                    xbmc.executebuiltin('RunPlugin('+url+')')
                else:
                    url = mu_playlist[index]
                    liz = xbmcgui.ListItem(playname, iconImage=iconimage)
                    liz.setInfo(type='Video', infoLabels={'Title':playname,'Plot':description})
                    liz.setProperty("IsPlayable","true")
                    liz.setPath(url)
                    playlist.add(url, liz)
                    if url.startswith("plugin://plugin.video.f4mTester"):
                        xbmc.executebuiltin('RunPlugin('+url+')')
                    else:
                        xbmc.Player().play(playlist)
                        xbmc.executebuiltin('PlayerControl(RepeatAll)')
        elif not queueVideo:
            #playlist = xbmc.PlayList(1) # 1 means video
            playlist.clear()
            item = 0
            for i in mu_playlist:
                item += 1
                info = xbmcgui.ListItem('%s) %s' %(str(item),name))
                # Don't do this as regex parsed might take longer
                try:
                    if "$doregex" in i:
                        sepate = i.split('&regexs=')
#                        print sepate
                        url,setresolved = getRegexParsed(sepate[1], sepate[0])
                    elif "&mode=19" in i:
                        url = urlsolver(i.replace('&mode=19','').replace(';',''))
                    if url:
                        playlist.add(url, info)
                    else:
                        raise
                except Exception:
                    playlist.add(i, info)
                    pass #xbmc.Player().play(url)
            xbmc.executebuiltin('playlist.playoffset(video,0)')
        else:
            listitem = xbmcgui.ListItem(name)
            playlist.add(mu_playlist, listitem)

def addDir(name,url,mode,iconimage,fanart,description,genre,date,credits,showcontext=False,regexs=None,reg_url=None,allinfo={}):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(str(description))
        ok=True
        folder=True
        if mode == 7:
            folder=False
        if date == '':
            date = None
        else:
            description += '\n\nDate: %s' %date
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        if len(allinfo) <1 :
            liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Genre": genre, "dateadded": date })
        else:
            liz.setInfo(type="Video", infoLabels= allinfo)
        liz.setProperty("Fanart_Image", fanart)
        if showcontext:
            contextMenu = []
            parentalblock =addon.getSetting('parentalblocked')
            parentalblock= parentalblock=="true"
            parentalblockedpin =addon.getSetting('parentalblockedpin')
#            print 'parentalblockedpin',parentalblockedpin
            if len(parentalblockedpin)>0:
                if parentalblock:
                    contextMenu.append(('Disable Parental Block','XBMC.RunPlugin(%s?mode=55&name=%s)' %(sys.argv[0], urllib.quote_plus(name))))
                else:
                    contextMenu.append(('Enable Parental Block','XBMC.RunPlugin(%s?mode=56&name=%s)' %(sys.argv[0], urllib.quote_plus(name))))
            elif showcontext == 'download':
                contextMenu.append(('Download','XBMC.RunPlugin(%s?url=%s&mode=9&name=%s)'
                                    %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
            if showcontext == '!!update':
                fav_params2 = (
                    '%s?url=%s&mode=17&regexs=%s'
                    %(sys.argv[0], urllib.quote_plus(reg_url), regexs)
                    )
                contextMenu.append(('[COLOR yellow]!!update[/COLOR]','XBMC.RunPlugin(%s)' %fav_params2))
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=folder)
        return ok


def ascii(string):
    if isinstance(string, basestring):
        if isinstance(string, unicode):
           string = string.encode('ascii', 'ignore')
    return string

def uni(string, encoding = 'utf-8'):
    if isinstance(string, basestring):
        if not isinstance(string, unicode):
            string = unicode(string, encoding, 'ignore')
    return string
def removeNonAscii(s): return "".join(filter(lambda x: ord(x)<128, s))

def sendJSON( command):
    data = ''
    try:
        data = xbmc.executeJSONRPC(uni(command))
    except UnicodeEncodeError:
        data = xbmc.executeJSONRPC(ascii(command))
    return uni(data)

def pluginquerybyJSON(url,give_me_result=None,playlist=False):
    if 'audio' in url:
        json_query = uni('{"jsonrpc":"2.0","method":"Files.GetDirectory","params": {"directory":"%s","media":"video", "properties": ["title", "album", "artist", "duration","thumbnail", "year"]}, "id": 1}') %url
    else:
        json_query = uni('{"jsonrpc":"2.0","method":"Files.GetDirectory","params":{"directory":"%s","media":"video","properties":[ "plot","playcount","director", "genre","votes","duration","trailer","premiered","thumbnail","title","year","dateadded","fanart","rating","season","episode","studio","mpaa"]},"id":1}') %url
    json_folder_detail = json.loads(sendJSON(json_query))
    #print json_folder_detail
    if give_me_result:
        return json_folder_detail
    if json_folder_detail.has_key('error'):
        return
    else:
        for i in json_folder_detail['result']['files'] :
            meta ={}
            url = i['file']
            name = removeNonAscii(i['label'])
            thumbnail = removeNonAscii(i['thumbnail'])
            fanart = removeNonAscii(i['fanart'])
            meta = dict((k,v) for k, v in i.iteritems() if not v == '0' or not v == -1 or v == '')
            meta.pop("file", None)
            if i['filetype'] == 'file':
                if playlist:
                    play_playlist(name,url,queueVideo='1')
                    continue
                else:
                    addLink(url,name,thumbnail,fanart,'','','','',None,'',total=len(json_folder_detail['result']['files']),allinfo=meta)
                    #xbmc.executebuiltin("Container.SetViewMode(500)")
                    if i['type'] and i['type'] == 'tvshow' :
                        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
                    elif i['episode'] > 0 :
                        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
            else:
                addDir(name,url,53,thumbnail,fanart,'','','','',allinfo=meta)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def addLink(url,name,iconimage,fanart,description,genre,date,showcontext,playlist,regexs,total,setCookie="",allinfo={}):
    #print 'url,name',url,name
    contextMenu =[]
    parentalblock =addon.getSetting('parentalblocked')
    parentalblock= parentalblock=="true"
    parentalblockedpin =addon.getSetting('parentalblockedpin')
#        print 'parentalblockedpin',parentalblockedpin
    if len(parentalblockedpin)>0:
        if parentalblock:
            contextMenu.append(('Disable Parental Block','XBMC.RunPlugin(%s?mode=55&name=%s)' %(sys.argv[0], urllib.quote_plus(name))))
        else:
            contextMenu.append(('Enable Parental Block','XBMC.RunPlugin(%s?mode=56&name=%s)' %(sys.argv[0], urllib.quote_plus(name))))
    try:
        name = name.encode('utf-8')
    except: pass
    ok = True
    isFolder=False
    if regexs:
        mode = '17'
        if 'listrepeat' in regexs:
            isFolder=True
#                print 'setting as folder in link'
        contextMenu.append(('[COLOR white]!!Download Currently Playing!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
                                %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
    elif  (any(x in url for x in resolve_url) and  url.startswith('http')) or url.endswith('&mode=19'):
        url=url.replace('&mode=19','')
        mode = '19'
        contextMenu.append(('[COLOR white]!!Download Currently Playing!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
                                %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
    elif url.endswith('&mode=18'):
        url=url.replace('&mode=18','')
        mode = '18'
        contextMenu.append(('[COLOR white]!!Download!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=23&name=%s)'
                                %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
        if addon.getSetting('dlaudioonly') == 'true':
            contextMenu.append(('!!Download [COLOR seablue]Audio!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
                                    %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
    elif 'netcine' in url:
        mode = '60'
    elif url.startswith('magnet:?xt='):
        if '&' in url and not '&' in url :
            url = url.replace('&','&')
        url = 'plugin://plugin.video.elementum/play?uri=' + url
        mode = '12'
    else:
        mode = '12'
        contextMenu.append(('[COLOR white]!!Download Currently Playing!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
                                %(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name))))
    if 'plugin://plugin.video.youtube/play/?video_id=' in url:
          yt_audio_url = url.replace('plugin://plugin.video.youtube/play/?video_id=','https://www.youtube.com/watch?v=')
          contextMenu.append(('!!Download [COLOR blue]Audio!![/COLOR]','XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
                                  %(sys.argv[0], urllib.quote_plus(yt_audio_url), urllib.quote_plus(name))))
    u=sys.argv[0]+"?"
    play_list = False
    if playlist:
        if addon.getSetting('add_playlist') == "false" and '$$LSPlayOnlyOne$$' not in playlist[0] :
            u += "url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
        else:
            #u += "mode=13&name="+urllib.quote_plus(name)+"&playlist="+urllib.quote_plus(str(playlist)).replace(',','||')
            u += "mode=13&name=%s&playlist=%s" %(urllib.quote_plus(name), urllib.quote_plus(str(playlist).replace(',','||')))
            u += "&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(str(description))
            name = name + '[B][COLOR orangered][B] (' + str(len(playlist)) + ' OPÇÕES )[/COLOR][/B]'
            play_list = True
    else:
        u += "url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(str(description))
    if regexs:
        u += "&regexs="+regexs
    if not setCookie == '':
        u += "&setCookie="+urllib.quote_plus(setCookie)
    if date == '':
        date = None
    else:
        description += '\n\nDate: %s' %date
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    if len(allinfo) <1:
        liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Genre": genre, "dateadded": date })
    else:
        liz.setInfo(type="Video", infoLabels=allinfo)
    liz.setProperty("Fanart_Image", fanart)
    if (not play_list) and not any(x in url for x in g_ignoreSetResolved) and not '$PLAYERPROXY$=' in url:#  (not url.startswith('plugin://plugin.video.f4mTester')):
        if regexs:
            #print urllib.unquote_plus(regexs)
            if '$pyFunction:playmedia(' not in urllib.unquote_plus(regexs) and 'notplayable' not in urllib.unquote_plus(regexs) and 'listrepeat' not in  urllib.unquote_plus(regexs) :
                #print 'setting isplayable',url, urllib.unquote_plus(regexs),url
                liz.setProperty('IsPlayable', 'true')
        else:
            liz.setProperty('IsPlayable', 'true')
    else:
        addon_log( 'NOT setting isplayable'+url)
    if url == 'here' or 'netcine' in url:
        liz.setProperty('IsPlayable', 'false')
    if int(player_f4m) == 0 and not url.endswith('.mp4') and not 'redecanais' in url:
        liz.setProperty('IsPlayable', 'false')
    if showcontext:
        #contextMenu = []
            fav_params = (
                '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
                %(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(url), urllib.quote_plus(iconimage), urllib.quote_plus(fanart))
                )
            if playlist:
                fav_params += 'playlist='+urllib.quote_plus(str(playlist).replace(',','||'))
            if regexs:
                fav_params += "&regexs="+regexs
    if not playlist is None:
        if addon.getSetting('add_playlist') == "false":
            playlist_name = name.split(') ')[1]
            contextMenu_ = [
                ('Play '+playlist_name+' PlayList','XBMC.RunPlugin(%s?mode=13&name=%s&playlist=%s)'
                 %(sys.argv[0], urllib.quote_plus(playlist_name), urllib.quote_plus(str(playlist).replace(',','||'))))
                 ]
            liz.addContextMenuItems(contextMenu_)
    #print 'adding',name
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,totalItems=total,isFolder=isFolder)
    #print 'added',name
    return ok

def F4M_Patch():
    f4mtester = xbmc.translatePath('special://home/addons/plugin.video.f4mTester')
    f4mproxy = xbmc.translatePath('special://home/addons/script.video.F4mProxy')
    try:
        fonte = getRequest2('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/f4mTester_default.py','','')
        if fonte:
            py = os.path.join(f4mtester, "default.py")
            file = open(py, "w")
            file.write(fonte)
            file.close()
        fonte = getRequest2('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/F4mProxy.py','','')
        if fonte:
            py = os.path.join(f4mproxy, "lib/F4mProxy.py")
            file = open(py, "w")
            file.write(fonte)
            file.close()
    except:
        pass

def CheckPlugin():
    try:
        Path = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path')).decode("utf-8")
        arquivo = os.path.join(Path, "jsunpack.py")
        exists = os.path.isfile(arquivo)
        if exists == False:
            fonte = urllib2.urlopen("http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/jsunpack.py").read()
            if fonte:
                py = os.path.join(Path, "jsunpack.py")
                file = open(py, "w")
                file.write(fonte)
                file.close()
    except:
        pass
    try:
        Path = xbmc.translatePath(os.path.join('special://home/userdata')).decode("utf-8")
        arquivo = os.path.join(Path, "advancedsettings.xml")
        exists = os.path.isfile(arquivo)
        if exists == False:
            base = '\x50\x47\x46\x6b\x64\x6d\x46\x75\x59\x32\x56\x6b\x63\x32\x56\x30\x64\x47\x6c\x75\x5a\x33\x4d\x2b\x43\x67\x6b\x38\x62\x47\x39\x6e\x62\x47\x56\x32\x5a\x57\x77\x2b\x4c\x54\x45\x38\x4c\x32\x78\x76\x5a\x32\x78\x6c\x64\x6d\x56\x73\x50\x67\x6f\x38\x4c\x32\x46\x6b\x64\x6d\x46\x75\x59\x32\x56\x6b\x63\x32\x56\x30\x64\x47\x6c\x75\x5a\x33\x4d\x2b'
            base = base64.b64decode(base).decode('utf-8')
            py = os.path.join(Path, "advancedsettings.xml")
            file = open(py, "w")
            file.write(base)
            file.close()
    except:
        pass

def check_addon():
    try:
        f4mproxy = xbmc.translatePath('special://home/addons/script.video.F4mProxy')
        f4mtester = xbmc.translatePath('special://home/addons/plugin.video.f4mTester')
        arquivo1 = os.path.join(f4mtester, "default.py")
        arquivo2 = os.path.join(f4mproxy, "lib/F4mProxy.py")
        try:
            #F4MTESTER
            with open(arquivo1, 'r') as content_file:
                content = content_file.read()
                if not 'description' in content:
                    F4M_Patch()
            #F4MPROXY
            with open(arquivo2, 'r') as content_file:
                content = content_file.read()
                if not 'description' in content:
                    F4M_Patch()
                elif not 'playlist' in content:
                    F4M_Patch()
        except:
            pass
        #print('Path dir:'+existe)
        #if os.path.exists(f4mproxy)==False:
        #    addon_name = 'F4mProxy'
        #    addon_id = 'script.video.F4mProxy'
        #    url_zip = 'http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/script.video.F4mProxy-2.8.7.zip'
        #    directory = 'special://home/addons/script.video.F4mProxy'
        #    install_f4m(addon_name,addon_id,url_zip,directory)
        #    anti_bug(addon_id)
        #if os.path.exists(f4mtester)==False:
        #    addon_name = 'F4mTester'
        #    addon_id = 'plugin.video.f4mTester'
        #    url_zip = 'http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/plugin.video.f4mTester-2.7.1.zip'
        #    directory = 'special://home/addons/plugin.video.f4mTester'
        #    install_f4m(addon_name,addon_id,url_zip,directory)
        #    anti_bug(addon_id)
    except:
        pass

def install_f4m(name,addon_id,url,directory):
    try:
        import downloader
        import extract
        import ntpath
        #import zipfile
        path = xbmc.translatePath(os.path.join('special://','home/','addons', 'packages'))
        filename = ntpath.basename(url)
        dp = xbmcgui.DialogProgress()
        dp.create("Install addons","Baixando "+name+"....",'', '')
        lib=os.path.join(path, filename)
        try:
         os.remove(lib)
        except:
            pass
        downloader.download(url, name, lib, dp)
        addonfolder = xbmc.translatePath(os.path.join('special://','home/','addons'))
        xbmc.sleep(100)
        dp.update(0,"", "Instalando "+name+", Por Favor Espere")
        try:
            xbmc.executebuiltin("Extract("+lib+","+addonfolder+")")
        except:
            extract.all(lib,addonfolder,dp)
        #############
        xbmc.sleep(100)
        xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
        import database
        database.enable_addon(0, addon_id)
        database.check_database(addon_id)
        xbmc.executebuiltin("XBMC.Container.Update()")
    except:
        notify('[B]Erro ao baixar os plugins[/B]')

def anti_bug(addon_id):
    import database
    database.enable_addon(0, addon_id)

def siteoficial():
    import xbmc
    import webbrowser
    if xbmc.getCondVisibility('system.platform.windows'):
        webbrowser.open('https://bit.ly/DOWNLOADSTWTUTORIAIS')
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,%s)' %('https://bit.ly/DOWNLOADSTWTUTORIAIS'))

def contador():
    try:
        request_headers = {
        "Accept-Language": "en-US,en;q=0.5",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,/;q=0.8",
        "Referer": "Net Cine by TWT - "+addon_version,
        "Connection": "close"
        }
        request = urllib2.Request("https://whos.amung.us/pingjs/?k=twtplayrepodl", headers=request_headers)
        response = urllib2.urlopen(request).read()
        #tempo_delay = 0
        #xbmc.sleep(tempo_delay*0)
    except:
        pass
contador()

def CheckUpdate():
    try:
        uversao = urllib2.urlopen('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/version.txt').read()
        uversao = re.compile('[a-zA-Z\.\d]+').findall(uversao)[0]
        if uversao != Versao:
            Update()
    except:
        xbmc.executebuiltin("XBMC.Notification([B][COLOR orangered]CHECK UPDATE FAIL![/COLOR][/B], [COLOR white][B]Atualização indisponível no momento.[/COLOR][/B]"+",5000,"+icon+")")
        if xbmcgui.Dialog().yesno(addon_name, '[B][COLOR white]Baixar o Update manualmente?[CR][CR]Houve um erro ao tentar atualizar automáticamente, verifique sua conexão ou horário do sistema.[/COLOR][/B]'):
            siteoficial()
            exit()
        else:
            exit()

def Update():
    Path = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path') ).decode("utf-8")
    try:
        fonte = urllib2.urlopen('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/database.py').read()
        prog = re.compile('checkintegrity08072020').findall(fonte)
        if prog:
            py = os.path.join(Path, "database.py")
            file = open(py, "w")
            file.write(fonte)
            file.close()
        fonte = urllib2.urlopen('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/default.py').read()
        prog = re.compile('checkintegrity08072020').findall(fonte)
        if prog:
            py = os.path.join(Path, "default.py")
            file = open(py, "w")
            file.write(fonte)
            file.close()
        fonte = urllib2.urlopen('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine//downloader.py').read()
        prog = re.compile('checkintegrity08072020').findall(fonte)
        if prog:
            py = os.path.join(Path, "downloader.py")
            file = open(py, "w")
            file.write(fonte)
            file.close()
        fonte = urllib2.urlopen('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/downloader_epg.py').read()
        prog = re.compile('checkintegrity08072020').findall(fonte)
        if prog:
            py = os.path.join(Path, "downloader_epg.py")
            file = open(py, "w")
            file.write(fonte)
            file.close()
        fonte = urllib2.urlopen('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/extract.py').read()
        prog = re.compile('checkintegrity08072020').findall(fonte)
        if prog:
            py = os.path.join(Path, "extract.py")
            file = open(py, "w")
            file.write(fonte)
            file.close()
        fonte = urllib2.urlopen('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/jsunpack.py').read()
        prog = re.compile('checkintegrity08072020').findall(fonte)
        if prog:
            py = os.path.join(Path, "jsunpack.py")
            file = open(py, "w")
            file.write(fonte)
            file.close()
        fonte = urllib2.urlopen('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/settings.xml').read()
        prog = re.compile('</settings>').findall(fonte)
        if prog:
            py = os.path.join(Path, "resources/settings.xml")
            file = open(py, "w")
            file.write(fonte)
            file.close()
        fonte = urllib2.urlopen('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/addon.xml').read()
        prog = re.compile('</addon>').findall(fonte)
        if prog:
            py = os.path.join(Path, "addon.xml")
            file = open(py, "w")
            file.write(fonte)
            file.close()
        uversao = urllib2.urlopen('http://qdodasformiguinhas.site/cuzoes/cuzoes2/newup/Flix/netcine/version.txt').read()
        uversao = re.compile('[a-zA-Z\.\d]+').findall(uversao)[0]
        xbmc.executebuiltin("XBMC.Notification([B][COLOR orangered]Update "+uversao+"[/COLOR][/B], [B][COLOR white]Atualização concluída[/COLOR][/B]"+",5000,"+icon+")")
    except:
        xbmcgui.Dialog().ok(addon_name, "[COLOR white][B]Não foi possível atualizar no momento, tente mais tarde.[/COLOR][/B]")

def playsetresolved(url,name,iconimage,setresolved=True):
    if setresolved:
        setres=True
        if '$$LSDirect$$' in url:
            url=url.replace('$$LSDirect$$','')
            setres=False
        liz = xbmcgui.ListItem(name, iconImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':name})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        if not setres:
            xbmc.Player().play(url)
        else:
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    else:
        xbmc.executebuiltin('XBMC.RunPlugin('+url+')')

def d2x(d, root="root",nested=0):
    op = lambda tag: '<' + tag + '>'
    cl = lambda tag: '</' + tag + '>\n'
    ml = lambda v,xml: xml + op(key) + str(v) + cl(key)
    xml = op(root) + '\n' if root else ""
    for key,vl in d.iteritems():
        vtype = type(vl)
        if nested==0: key='regex' #enforcing all top level tags to be named as regex
        if vtype is list:
            for v in vl:
                v=escape(v)
                xml = ml(v,xml)
        if vtype is dict:
            xml = ml('\n' + d2x(vl,None,nested+1),xml)
        if vtype is not list and vtype is not dict:
            if not vl is None: vl=escape(vl)
            #print repr(vl)
            if vl is None:
                xml = ml(vl,xml)
            else:
                #xml = ml(escape(vl.encode("utf-8")),xml)
                xml = ml(vl.encode("utf-8"),xml)
    xml += cl(root) if root else ""
    return xml
xbmcplugin.setContent(int(sys.argv[1]), 'movies')
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATE)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_GENRE)
except:
    pass
params=get_params()
url=None
name=None
mode=None
playlist=None
iconimage=None
fanart=FANART
playlist=None
fav_mode=None
regexs=None
try:
    url=urllib.unquote_plus(params["url"]).decode('utf-8')
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    fanart=urllib.unquote_plus(params["fanart"])
except:
    pass
try:
    description=urllib.unquote_plus(params["description"])
except:
    pass
try:
    mode=int(params["mode"])
except:
    pass
try:
    playlist=eval(urllib.unquote_plus(params["playlist"]).replace('||',','))
except:
    pass
try:
    fav_mode=int(params["fav_mode"])
except:
    pass
try:
    regexs=params["regexs"]
except:
    pass
playitem=''
try:
    playitem=urllib.unquote_plus(params["playitem"])
except:
    pass
addon_log("Mode: "+str(mode))
if not url is None:
 addon_log("URL: "+str(url.encode('utf-8')))
 addon_log("Name: "+str(name))
if not playitem =='':
    s=getSoup('',data=playitem)
    name,url,regexs=getItems(s,None,dontLink=True)
    mode=117
if mode==None:
    CheckUpdate()
    CheckPlugin()
    import burn
    burn.byebyeBoaNoite()
    if int(player_f4m) == 0: check_addon()
    if epgEnabled == "true": updateEPG()
    parental_password()
    CHIndex()
elif mode==1:
    addon_log("getData")
    CheckUpdate()
    CheckPlugin()
    if int(player_f4m) == 0: check_addon()
    if epgEnabled == "true": updateEPG()
    parental_password()
    if canais_adultos == 'true' and name.find("CANAIS") >= 0 and name.find("+18") >= 0:
        adult()
    data=None
    if regexs:
        data=getRegexParsed(regexs, url)
        url=''
        #create xml here
    getData(url,fanart,data)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode==2:
    getChannelItems(name,url,fanart)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode==3:
    getSubChannelItems(name,url,fanart)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode==4:
    getFavorites()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode==5:
    addon_log("addFavorite")
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]
    except:
        pass
    addFavorite(name,url,iconimage,fanart,fav_mode)
elif mode==6:
    addon_log("rmFavorite")
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]
    except:
        pass
    rmFavorite(name)
elif mode==7:
    xbmcaddon.Addon().openSettings()
    xbmc.executebuiltin("XBMC.Container.Refresh()")
    exit()
elif mode==12:
    #addon_log("setResolvedUrl")
    if canais_adultos == 'true' and re.search("rs1=",url,re.IGNORECASE) and re.search(".mp4",url,re.IGNORECASE) or 'pornhub' in url or re.search("PlayBoy",name,re.IGNORECASE) or re.search("SexyHot",name,re.IGNORECASE) or re.search("SexTreme",name,re.IGNORECASE) or re.search("Venus",name,re.IGNORECASE):
        adult()
    if not url.startswith("plugin://plugin"):
        if url.find('redecanais') >= 0: #REDECANAIS
            url = resolver_rc(url)
            xbmc.executebuiltin('PlayerControl(RepeatOff)')
        if url.find('twt1=') >= 0 or url.find('twt2=') >= 0 or url.find('twt3=') >= 0 or url.find('twt4=') >= 0 or url.find('twt5=') >= 0 or url.find('tw1=') >= 0 or url.find('tw2=') >= 0 or url.find('tw3=') >= 0 or url.find('tw4=') >= 0 or url.find('tw5=') >= 0 or url.find('tw6=') >= 0 or url.find('tw7=') >= 0 or url.find('tw8=') >= 0 or url.find('tw9=') >= 0 or url.find('tw10=') >= 0 or url.find('tw11=') >= 0 or url.find('tw12=') >= 0 or url.find('tw13=') >= 0 or url.find('tw14=') >= 0 or url.find('tw15=') >= 0 and url.find('mp4') >= 0:
            url = twts_mp4(url)
            xbmc.executebuiltin('PlayerControl(RepeatOff)')
        elif url.find('rs1=') >= 0 and url.find('mp4') >= 0: #REDISEX
            url = tws_mp4(url)
            xbmc.executebuiltin('PlayerControl(RepeatOff)')
        elif 'pornhub' in url: #PORNHUB
            url = hub_resolver(url)
            xbmc.executebuiltin('PlayerControl(RepeatOff)')
        elif url.find('tw1_m3u8=') >= 0 and url.find('m3u8') >= 0:
            url = twt1_m3u8(url)
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
        elif url.find('tw2_m3u8=') >= 0 and url.find('m3u8') >= 0:
            url = twt2_m3u8(url)
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
        elif 'twt1=' in url or 'twt2=' in url or 'twt3=' in url or 'twt4=' in url or 'twt5=' in url or 'twt6=' in url or 'twt7=' in url or 'twt8=' in url or 'twt9=' in url or 'twt10=' in url:
            url = server_twt2(url)
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
        elif url.find('twttv3=') >= 0 and url.find('m3u8') >= 0:
            url = server_twt3(url)
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
        elif url.find('twttv4=') >= 0 and url.find('m3u8') >= 0:
            url = server_twt4(url)
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
        elif url.find('twttv5=') >= 0 and url.find('m3u8') >= 0:
            url = server_twt5(url)
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
        elif url.find('twttv6=') >= 0 and url.find('m3u8') >= 0:
            url = server_twt6(url)
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
        elif 'canaismix=' in url and 'm3u8' in url:
            url = CanaisMix(url)
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
        elif url.find('booyah=') >= 0 and url.find('m3u8') >= 0:
            url = server_booyah(url)
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
        elif url.find('ch24h=') >= 0 and url.find('m3u8') >= 0:
            url = server_ch24h(url)
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
        elif 'https://' in url or 'http://' in url and '.m3u8' in url and int(player_f4m) == 0:
            url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        elif 'https://' in url or 'http://' in url and '.ts' in url and int(player_f4m) == 0:
            url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name='+urllib.quote_plus(str(name))+"&iconImage="+urllib.quote_plus(iconimage)+'&url='+urllib.quote_plus(url)+'&description='+urllib.quote_plus(description)
        elif url == 'here' and 'CANAIS ABERTOS' in name or 'CANAIS ABERTOS' in name or 'DOCUMENTÁRIOS' in name or 'ESPORTES' in name or 'FILMES & SÉRIES' in name or 'INFATIL' in name or 'MÚSICAS & VARIEDADES' in name or 'NOTÍCIAS' in name:
            if epgEnabled == "true":
                notify('[B]Atualizando o EPG...[/B]')
                xbmc.executebuiltin("Container.Refresh")
        else:
            xbmc.executebuiltin('PlayerControl(RepeatAll)')
        if url == '' or url == None:
            exit()
        if int(player_f4m) == 0 and not url.find('.mp4') >= 0 and 'plugin://plugin' in url:
            xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
        else:
            liz = xbmcgui.ListItem(path=url)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    else:
        xbmc.executebuiltin('XBMC.RunPlugin('+url+')')
elif mode==13:
    addon_log("play_playlist")
    play_playlist(name,description,iconimage,playlist)
elif mode==17 or mode==117:
    addon_log("getRegexParsed")
    data=None
    if regexs and 'listrepeat' in urllib.unquote_plus(regexs):
        listrepeat,ret,m,regexs =getRegexParsed(regexs, url)
        #print listrepeat,ret,m,regexs
        d=''
#        print 'm is' , m
#        print 'regexs',regexs
        regexname=m['name']
        existing_list=regexs.pop(regexname)
 #       print 'final regexs',regexs,regexname
        url=''
        import copy
        ln=''
        rnumber=0
        for obj in ret:
            try:
                rnumber+=1
                newcopy=copy.deepcopy(regexs)
    #            print 'newcopy',newcopy, len(newcopy)
                listrepeatT=listrepeat
                i=0
                for i in range(len(obj)):
    #                print 'i is ',i, len(obj), len(newcopy)
                    if len(newcopy)>0:
                        for the_keyO, the_valueO in newcopy.iteritems():
                            if the_valueO is not None:
                                for the_key, the_value in the_valueO.iteritems():
                                    if the_value is not None:
        #                                print  'key and val',the_key, the_value
        #                                print 'aa'
        #                                print '[' + regexname+'.param'+str(i+1) + ']'
        #                                print repr(obj[i])
                                        if type(the_value) is dict:
                                            for the_keyl, the_valuel in the_value.iteritems():
                                                if the_valuel is not None:
                                                    if isinstance(obj,tuple):
                                                        try:
                                                            the_value[the_keyl]=the_valuel.replace('[' + regexname+'.param'+str(i+1) + ']', obj[i].decode('utf-8') )
                                                        except:
                                                            the_value[the_keyl]=the_valuel.replace('[' + regexname+'.param'+str(i+1) + ']', obj[i] )
                                                    else:
                                                        try:
                                                            the_value[the_keyl]=the_valuel.replace('[' + regexname+'.param'+str(i+1) + ']', obj.decode('utf-8') )
                                                        except:
                                                            the_value[the_keyl]=the_valuel.replace('[' + regexname+'.param'+str(i+1) + ']', obj)
                                        else:
                                            if isinstance(obj,tuple):
                                                try:
                                                     the_valueO[the_key]=the_value.replace('[' + regexname+'.param'+str(i+1) + ']', obj[i].decode('utf-8') )
                                                except:
                                                    the_valueO[the_key]=the_value.replace('[' + regexname+'.param'+str(i+1) + ']', obj[i] )
                                            else:
                                                try:
                                                    the_valueO[the_key]=the_value.replace('[' + regexname+'.param'+str(i+1) + ']', obj.decode('utf-8') )
                                                except:
                                                    the_valueO[the_key]=the_value.replace('[' + regexname+'.param'+str(i+1) + ']', obj)
                    if isinstance(obj,tuple):
                        try:
                            listrepeatT=listrepeatT.replace('[' + regexname+'.param'+str(i+1) + ']',obj[i].decode('utf-8'))
                        except:
                            listrepeatT=listrepeatT.replace('[' + regexname+'.param'+str(i+1) + ']',obj[i])
                    else:
                        try:
                            listrepeatT=listrepeatT.replace('[' + regexname+'.param'+str(i+1) + ']',obj.decode('utf-8'))
                        except:
                            listrepeatT=listrepeatT.replace('[' + regexname+'.param'+str(i+1) + ']',obj)
#                    print listrepeatT
                listrepeatT=listrepeatT.replace('[' + regexname+'.param'+str(0) + ']',str(rnumber))
                #newcopy = urllib.quote(repr(newcopy))
    #            print 'new regex list', repr(newcopy), repr(listrepeatT)
    #            addLink(listlinkT,listtitleT.encode('utf-8', 'ignore'),listthumbnailT,'','','','',True,None,newcopy, len(ret))
                regex_xml=''
                if len(newcopy)>0:
                    regex_xml=d2x(newcopy,'lsproroot')
                    regex_xml=regex_xml.split('<lsproroot>')[1].split('</lsproroot')[0]
                #ln+='\n<item>%s\n%s</item>'%(listrepeatT.encode("utf-8"),regex_xml)
                try:
                    ln+='\n<item>%s\n%s</item>'%(listrepeatT,regex_xml)
                except: ln+='\n<item>%s\n%s</item>'%(listrepeatT.encode("utf-8"),regex_xml)
            except: traceback.print_exc(file=sys.stdout)
#            print repr(ln)
#            print newcopy
#            ln+='</item>'
        #print 'ln',repr(ln)
        addon_log(repr(ln))
        getData('','',ln)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    else:
        url,setresolved = getRegexParsed(regexs, url)
        #print repr(url),setresolved,'imhere'
        if url:
            if '$PLAYERPROXY$=' in url:
                url,proxy=url.split('$PLAYERPROXY$=')
                #print 'proxy',proxy
                proxyip,port=proxy.split(':')
                playmediawithproxy(url,name,iconimage,proxyip,port )
            else:
                playsetresolved(url,name,iconimage,setresolved)
        else:
            xbmc.executebuiltin("XBMC.Notification("+addon_name+",Failed to extract regex. - "+"this"+",4000,"+icon+")")
elif mode==17:
    CheckUpdate()
    xbmc.executebuiltin("XBMC.Container.Refresh()")
elif mode==19:
    addon_log("Genesiscommonresolvers")
    playsetresolved (urlsolver(url),name,iconimage,True)
elif mode==53:
    addon_log("Requesting JSON-RPC Items")
    pluginquerybyJSON(url)
    #xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode==54:
    pesquisar_filmes()
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    xbmc.sleep(50)
    xbmc.executebuiltin('Container.SetViewMode(54)')
elif mode==55:
    series_episodios(url,name,iconimage)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode==56:
    series_episodios_show(url,name,iconimage)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode==57:
    dubladooulegendado(url,name,iconimage)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode==58:
    pornhub(name,url,fanart)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    xbmc.sleep(50)
    xbmc.executebuiltin('Container.SetViewMode(500)')
elif mode==59:
    if '#netcine_menu' in url:
        addDir('[B][COLOR white]PESQUISE POR FILMES[/COLOR][/B]','#pesquisar_netcine',59,'https://i.imgur.com/sWVwDdH.png','https://i.imgur.com/loafNUU.jpg','[B][COLOR white]PESQUISE O SEU FILME FAVORITO[/COLOR][/B]','','',None)
        addDir('[B][COLOR white]CATEGORIA: [COLOR mediumblue]FILMES[/COLOR][/COLOR][/B]','https://netcine.biz/?filmes',59,'https://i.imgur.com/sWVwDdH.png','https://i.imgur.com/loafNUU.jpg','[B][COLOR white]OS MELHORES FILMES [COLOR mediumblue]NETCINE[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','',None)
        addDir('[B][COLOR white]CATEGORIA: [COLOR mediumblue]GENÊROS[/COLOR][/COLOR][/B]','#genre',59,'https://i.imgur.com/UY2sgC0.png','https://i.imgur.com/loafNUU.jpg','[B][COLOR white]FILMES ORGANIZADOS POR [COLOR mediumblue]GÊNERO[/COLOR][/COLOR][/B]','','',None)
        addDir('[B][COLOR white]CATEGORIA: [COLOR mediumblue]LANÇAMENTOS[/COLOR][/COLOR][/B]','https://netcine.biz/ano-lancamento/2021/',59,'https://i.imgur.com/OPMzTas.png','https://i.imgur.com/loafNUU.jpg','[B][COLOR mediumblue]MELHORES LANÇAMENTOS[/COLOR][/B]','','',None)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif '#pesquisar_netcine' in url:
        keyb = xbmc.Keyboard('', 'PESQUISE O SEU FILME FAVORITO')
        keyb.doModal()
        if (keyb.isConfirmed()):
            search = keyb.getText()
            search = remover_acentos(search)
            search = search.lower()
            if search == '' or search == ' ' or search == '  ':
                exit()
            search = 'https://netcine.biz/?s=' + search.replace(' ','+')
            netcine_filmes(name, search, fanart)
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            xbmc.sleep(50)
            xbmc.executebuiltin('Container.SetViewMode(500)')
        else:
            exit()
    elif '#genre' in url:
        genre=[
            ("AÇÃO", "https://netcine.biz/category/acao/"),
            ("ANIMAÇÃO", "https://netcine.biz/category/animacao/"),
            ("AVENTURA", "https://netcine.biz/category/aventura/"),
            ("BIOGRAFIA", "https://netcine.biz/category/biografia/"),
            ("COMÉDIA", "https://netcine.biz/category/comedia/"),
            ("CRIME", "https://netcine.biz/category/crime/"),
            ("DOCUMENTÁRIO", "https://netcine.biz/category/documentario/"),
            ("DRAMA", "https://netcine.biz/category/drama/"),
            ("FAMÍLIA", "https://netcine.biz/category/familia/"),
            ("FANTASIA", "https://netcine.biz/category/fantasia/"),
            ("FAROESTE", "https://netcine.biz/category/faroeste/"),
            ("FIÇÃO CIENTÍFICA", "https://netcine.biz/category/ficcao-cientifica/"),
            ("GUERRA", "https://netcine.biz/category/guerra/"),
            ("MISTÉRIO", "https://netcine.biz/category/misterio/"),
            ("MÚSICAL", "https://netcine.biz/category/musical/"),
            ("POLICIAL", "https://netcine.biz/category/policial/"),
            ("ROMANCE", "https://netcine.biz/category/romance/"),
            ("SUSPENSE", "https://netcine.biz/category/suspense/"),
            ("TERROR", "https://netcine.biz/category/terror/")
            ]
        for genero, url in genre:
            addDir('[B][COLOR white]CATEGORIA: [COLOR mediumblue]'+genero+'[/COLOR][/COLOR][/B]',url,59,'https://i.imgur.com/UY2sgC0.png','https://i.imgur.com/loafNUU.jpg','[B][COLOR white]FILMES ORGANIZADOS POR [COLOR mediumblue]GÊNERO[/COLOR][/COLOR][/B]','','',None)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif '/tvshows/' in url and not url.endswith('/tvshows/') and not '/page/' in url:
        netcine_series_list(name, url, iconimage, fanart)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        xbmc.sleep(50)
        xbmc.executebuiltin('Container.SetViewMode(54)')
    elif '/tvshows/' in url:
        netcine_series(name, url, fanart)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        xbmc.sleep(50)
        xbmc.executebuiltin('Container.SetViewMode(500)')
    else:
        netcine_filmes(name, url, fanart)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        xbmc.sleep(50)
        xbmc.executebuiltin('Container.SetViewMode(500)')
elif mode==60:
    notify('[B]Resolvendo... Aguarde![/B]', 1000)
    url = netcine_resolver(url)
    if re.search("LEG",url,re.IGNORECASE):
        name = name + ' [B][COLOR orangered](LEGENDADO)[/COLOR][/B]'
    if not url == '' and not url == None:
        notify('[B]Reproduzindo... Divirta-se![/B]', 1000)
        #playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        #playlist.clear()
        li = xbmcgui.ListItem(name, path=url)
        li.setArt({"icon": iconimage, "thumb": iconimage})
        li.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
        #playlist.add(url, li)
        xbmc.Player().play(url, li)
        xbmc.executebuiltin('PlayerControl(RepeatOff)')
elif mode==61:
    netcine_series_show(name, url, iconimage, fanart)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    xbmc.sleep(50)
    xbmc.executebuiltin('Container.SetViewMode(50)')
if not viewmode==None:
    #print 'setting view mode'
    xbmc.executebuiltin("Container.SetViewMode(%s)"%viewmode)
