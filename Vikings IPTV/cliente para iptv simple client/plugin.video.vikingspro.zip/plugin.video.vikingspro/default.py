import xbmc
import xbmcgui
import xbmcaddon
import os
import xbmcvfs

kodi = float(xbmc.getInfoLabel("System.BuildVersion")[:4])

if kodi > 19:
    import xbmcvfs as xbmc
else:
    import xbmc

addon = xbmcaddon.Addon(id='plugin.video.vikingspro')
login1 = addon.getSetting('login')
password1 = addon.getSetting('password')

tv  = os.path.join(xbmc.translatePath("special://home/userdata/addon_data/pvr.iptvsimple/settings.xml"))


    

def main(login,password):
    dialog = xbmcgui.Dialog()
    menu = dialog.select('Ola Bem Vindos ao Vikings Pro', ['Pedir um Teste','Configurar meu Login','Bonus 1 Radio Tops','Bonus 2 RSA Music','Bonus 3 Kiss FM Radio Rock'])

    if menu == 0:
        dialog = xbmcgui.Dialog()
        ok = dialog.ok('Vikings Pro', 'Para Gerar o Teste sera necessario entrar contato nesse whatsapp 55 1196396-4599, e digitar "SOU VIKINGS"')

        dialog = xbmcgui.Dialog()
        ok = dialog.ok('Vikings Pro', 'Entao corre lah, entre em contato conosco para obter o teste de streaming de baixo custo, sem travas!')

    if menu == 1:
        #dialog = xbmcgui.Dialog()
        #login = dialog.input('[COLOR yellow]Digite o Login: [/COLOR]','', type=xbmcgui.INPUT_ALPHANUM)

        #dialog = xbmcgui.Dialog()
        #password = dialog.input('[COLOR yellow]Digite a Senha: [/COLOR]','', type=xbmcgui.INPUT_ALPHANUM)

        file = open(tv,"w") 

        file.write("<settings version=\"2\">\n") 
        file.write("    <setting id=\"m3uPathType\" default=\"true\">1</setting>\n") 
        file.write("    <setting id=\"m3uPath\" default=\"true\" />\n") 
        file.write("    <setting id=\"m3uUrl\">http://load.casaplayer.com.br/get.php?username="+login+"&amp;password="+password+"&amp;type=m3u_plus&amp;output=ts</setting>\n") 
        file.write("    <setting id=\"m3uCache\">false</setting>\n") 
        file.write("    <setting id=\"startNum\" default=\"true\">1</setting>\n") 
        file.write("    <setting id=\"numberByOrder\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"m3uRefreshMode\" default=\"true\">0</setting>\n") 
        file.write("    <setting id=\"m3uRefreshIntervalMins\" default=\"true\">60</setting>\n") 
        file.write("    <setting id=\"m3uRefreshHour\" default=\"true\">4</setting>\n") 
        file.write("    <setting id=\"tvGroupMode\" default=\"true\">0</setting>\n") 
        file.write("    <setting id=\"numTvGroups\" default=\"true\">1</setting>\n") 
        file.write("    <setting id=\"oneTvGroup\" default=\"true\" />\n") 
        file.write("    <setting id=\"twoTvGroup\" default=\"true\" />\n") 
        file.write("    <setting id=\"threeTvGroup\" default=\"true\" />\n") 
        file.write("    <setting id=\"fourTvGroup\" default=\"true\" />\n") 
        file.write("    <setting id=\"fiveTvGroup\" default=\"true\" />\n") 
        file.write("    <setting id=\"customTvGroupsFile\" default=\"true\">special://userdata/addon_data/pvr.iptvsimple/channelGroups/customTVGroups-example.xml</setting>\n") 
        file.write("    <setting id=\"tvChannelGroupsOnly\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"radioGroupMode\" default=\"true\">0</setting>\n") 
        file.write("    <setting id=\"numRadioGroups\" default=\"true\">1</setting>\n") 
        file.write("    <setting id=\"oneRadioGroup\" default=\"true\" />\n") 
        file.write("    <setting id=\"twoRadioGroup\" default=\"true\" />\n") 
        file.write("    <setting id=\"threeRadioGroup\" default=\"true\" />\n") 
        file.write("    <setting id=\"fourRadioGroup\" default=\"true\" />\n") 
        file.write("    <setting id=\"fiveRadioGroup\" default=\"true\" />\n") 
        file.write("    <setting id=\"customRadioGroupsFile\" default=\"true\">special://userdata/addon_data/pvr.iptvsimple/channelGroups/customRadioGroups-example.xml</setting>\n") 
        file.write("    <setting id=\"radioChannelGroupsOnly\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"epgPathType\" default=\"true\">1</setting>\n") 
        file.write("    <setting id=\"epgPath\" default=\"true\" />\n") 
        file.write("    <setting id=\"epgUrl\">http://load.casaplayer.com.br/xmltv.php?username="+login+"&amp;password="+password+"&amp;type=m3u_plus&amp;output=ts</setting>\n") 
        file.write("    <setting id=\"epgCache\" default=\"true\">true</setting>\n") 
        file.write("    <setting id=\"epgTimeShift\" default=\"true\">0</setting>\n") 
        file.write("    <setting id=\"epgTSOverride\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"useEpgGenreText\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"genresPathType\" default=\"true\">0</setting>\n") 
        file.write("    <setting id=\"genresPath\" default=\"true\">special://userdata/addon_data/pvr.iptvsimple/genres/genreTextMappings/genres.xml</setting>\n") 
        file.write("    <setting id=\"genresUrl\" default=\"true\" />\n") 
        file.write("    <setting id=\"logoPathType\" default=\"true\">1</setting>\n") 
        file.write("    <setting id=\"logoPath\" default=\"true\" />\n") 
        file.write("    <setting id=\"logoBaseUrl\" default=\"true\" />\n") 
        file.write("    <setting id=\"logoFromEpg\" default=\"true\">1</setting>\n") 
        file.write("    <setting id=\"timeshiftEnabled\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"timeshiftEnabledAll\" default=\"true\">true</setting>\n") 
        file.write("    <setting id=\"timeshiftEnabledHttp\" default=\"true\">true</setting>\n") 
        file.write("    <setting id=\"timeshiftEnabledUdp\" default=\"true\">true</setting>\n") 
        file.write("    <setting id=\"timeshiftEnabledCustom\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"catchupEnabled\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"catchupQueryFormat\" default=\"true\" />\n") 
        file.write("    <setting id=\"catchupDays\" default=\"true\">5</setting>\n") 
        file.write("    <setting id=\"allChannelsCatchupMode\" default=\"true\">0</setting>\n") 
        file.write("    <setting id=\"catchupOverrideMode\" default=\"true\">0</setting>\n") 
        file.write("    <setting id=\"catchupPlayEpgAsLive\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"catchupWatchEpgBeginBufferMins\" default=\"true\">5</setting>\n") 
        file.write("    <setting id=\"catchupWatchEpgEndBufferMins\" default=\"true\">15</setting>\n") 
        file.write("    <setting id=\"catchupOnlyOnFinishedProgrammes\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"transformMulticastStreamUrls\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"udpxyHost\" default=\"true\">127.0.0.1</setting>\n") 
        file.write("    <setting id=\"udpxyPort\" default=\"true\">4022</setting>\n") 
        file.write("    <setting id=\"useFFmpegReconnect\" default=\"true\">true</setting>\n") 
        file.write("    <setting id=\"useInputstreamAdaptiveforHls\" default=\"true\">false</setting>\n") 
        file.write("    <setting id=\"defaultUserAgent\" default=\"true\" />\n") 
        file.write("    <setting id=\"defaultInputstream\" default=\"true\" />\n") 
        file.write("    <setting id=\"defaultMimeType\" default=\"true\" />\n") 
        file.write("</settings>\n") 
        file.close()

        dialog = xbmcgui.Dialog()
        ok = dialog.ok('Vikings Pro', 'Senha Colocada com sucesso necessario reniciar o Kodi. E entre depois na aba TV para que possa ser configurado sua TV')


    if menu == 2:
        import radiotop
        radiotop.radio_top()

    if menu == 3:
        import rsamusic
        rsamusic.rsa_music()

    if menu == 4:
        import kissfm
        kissfm.kiss_music()        

        
login = login1
password = password1

main(login,password)
