import os
import xbmcgui

def killxbmc():
    choice = xbmcgui.Dialog().yesno('A Build Foi Instalada com Sucesso para carregar', 'Para Terminar preciso Encerrar o Kodi posso ? ?', nolabel='Nao',yeslabel='Sim')
    if choice == 0:
        return
    elif choice == 1:
        xbmc.executebuiltin("Quit")
 